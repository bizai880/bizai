-- infra/docker/postgres/init-dev/init.sql
-- Development Database Initialization

-- Create development database
CREATE DATABASE bizai_development;

-- Connect to development database
\c bizai_development;

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Create test users
INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, created_at, updated_at)
VALUES 
  (
    '00000000-0000-0000-0000-000000000001',
    'admin@bizai.com',
    crypt('admin123', gen_salt('bf')),
    NOW(),
    NOW(),
    NOW()
  ),
  (
    '00000000-0000-0000-0000-000000000002',
    'user@bizai.com',
    crypt('user123', gen_salt('bf')),
    NOW(),
    NOW(),
    NOW()
  )
ON CONFLICT (id) DO NOTHING;

-- Insert test data for generations
INSERT INTO generations (id, user_id, prompt, result, model_used, tokens_used, status)
VALUES 
  (
    '10000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001',
    'Create an Excel report for Q1 sales',
    '{"file_url": "https://example.com/report.xlsx", "status": "completed"}',
    'gpt-4',
    1500,
    'completed'
  ),
  (
    '10000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000002',
    'Generate dashboard for user analytics',
    '{"file_url": "https://example.com/dashboard.pdf", "status": "processing"}',
    'gemini-pro',
    2000,
    'processing'
  )
ON CONFLICT (id) DO NOTHING;

-- Log initialization
DO $$
BEGIN
  RAISE NOTICE 'Development database initialized successfully at %', NOW();
END $$;