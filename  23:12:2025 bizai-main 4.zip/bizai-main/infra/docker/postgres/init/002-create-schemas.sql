-- infra/docker/postgres/init/002-create-schemas.sql
-- Create database schemas

-- Create main schemas
CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS app;
CREATE SCHEMA IF NOT EXISTS ai;
CREATE SCHEMA IF NOT EXISTS billing;
CREATE SCHEMA IF NOT EXISTS analytics;
CREATE SCHEMA IF NOT EXISTS audit;

-- Set schema search path
ALTER DATABASE CURRENT SET search_path TO app, auth, ai, billing, analytics, audit, public;

-- Grant permissions
GRANT USAGE ON SCHEMA auth TO ${POSTGRES_USER};
GRANT USAGE ON SCHEMA app TO ${POSTGRES_USER};
GRANT USAGE ON SCHEMA ai TO ${POSTGRES_USER};
GRANT USAGE ON SCHEMA billing TO ${POSTGRES_USER};
GRANT USAGE ON SCHEMA analytics TO ${POSTGRES_USER};
GRANT USAGE ON SCHEMA audit TO ${POSTGRES_USER};

-- Create readonly user for reporting
CREATE USER bizai_readonly WITH PASSWORD '${DB_READONLY_PASSWORD:-readonly_pass}';
GRANT CONNECT ON DATABASE ${POSTGRES_DB} TO bizai_readonly;
GRANT USAGE ON SCHEMA analytics TO bizai_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO bizai_readonly;