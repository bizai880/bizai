#!/bin/bash
cd /workspaces/bizai

echo "🔧 إصلاح المشكلة مع Next.js 15.5.9..."

# 1. التحقق من الإصدار الحالي في apps/web
echo "📊 التحقق من إصدار Next.js في apps/web..."
cd apps/web
CURRENT_NEXT_VERSION=$(grep '"next"' package.json | head -1 | sed 's/.*"next": "\([^"]*\)".*/\1/')
echo "الإصدار الحالي في apps/web: $CURRENT_NEXT_VERSION"

# 2. إذا لم يكن 15.5.9، تصحيحه
if [[ "$CURRENT_NEXT_VERSION" != "15.5.9" ]]; then
    echo "🔄 تصحيح إصدار Next.js إلى 15.5.9..."
    npm install next@15.5.9
fi

# 3. التحقق من node_modules الرئيسي
echo "🔍 التحقق من node_modules الرئيسي..."
cd /workspaces/bizai

# إذا كان هناك next في node_modules الرئيسي، تأكد أنه 15.5.9
if [ -d "node_modules/next" ]; then
    echo "📦 تحديث Next.js في المجلد الرئيسي إلى 15.5.9..."
    npm install next@15.5.9 --save-dev
fi

# 4. تنظيف شامل
echo "🧹 تنظيف شامل..."
cd apps/web
rm -rf .next
rm -rf node_modules/.cache

# 5. البناء
echo "🔨 البناء مع Next.js 15.5.9..."
npm run build 2>&1 | tee build-15.5.9.log

if [ $? -eq 0 ]; then
    echo "✅ تم البناء بنجاح مع Next.js 15.5.9!"
    
    # 6. بناء جميع المشاريع
    cd /workspaces/bizai
    echo "🚀 بناء جميع المشاريع..."
    npm run build
else
    echo "❌ فشل البناء"
    echo "📋 الأخطاء:"
    tail -50 build-15.5.9.log
    
    # 7. حل المشكلة الحقيقية: @next/env المفقود
    echo "🔧 حل مشكلة @next/env المفقود..."
    cd /workspaces/bizai
    
    # أ. حذف @next/env التالف
    rm -rf node_modules/@next 2>/dev/null || true
    
    # ب. إعادة تثبيت next مع الإصدار الصحيح
    npm install next@15.5.9 --save-dev
    
    # ج. المحاولة مرة أخرى
    cd apps/web
    npm run build
fi