#!/bin/bash
cd /workspaces/bizai

echo "🔧 إصلاح @next/env بدون تغيير الإصدارات..."

# 1. أولاً، احذف @next/env التالف
echo "🗑️  إزالة @next/env التالف..."
rm -rf node_modules/@next 2>/dev/null || true

# 2. تأكد من أن next مثبت في المجلد الرئيسي (للتأكد من وجود @next/env)
echo "📦 التأكد من وجود next في node_modules الرئيسي..."
if [ ! -d "node_modules/next" ]; then
    echo "➕ تثبيت next في المجلد الرئيسي (للتطوير فقط)..."
    # احصل على إصدار next من apps/web
    cd apps/web
    NEXT_VERSION=$(grep '"next"' package.json | head -1 | sed 's/.*"next": "\([^"]*\)".*/\1/')
    cd /workspaces/bizai
    npm install next@$NEXT_VERSION --save-dev
else
    echo "✅ next موجود بالفعل في المجلد الرئيسي"
fi

# 3. التحقق من أن @next/env موجود الآن
echo "🔍 التحقق من @next/env..."
if [ -f "node_modules/@next/env/dist/index.js" ]; then
    echo "✅ @next/env موجود الآن"
else
    echo "❌ @next/env لا يزال مفقوداً، إعادة تثبيت next بالكامل"
    rm -rf node_modules/next node_modules/@next
    cd apps/web
    NEXT_VERSION=$(grep '"next"' package.json | head -1 | sed 's/.*"next": "\([^"]*\)".*/\1/')
    cd /workspaces/bizai
    npm install next@$NEXT_VERSION --save-dev
fi

# 4. الآن حاول بناء apps/web
echo "🔄 بناء apps/web..."
cd apps/web

# تنظيف
rm -rf .next node_modules/.cache

# البناء
npm run build 2>&1 | tee final-build.log

if [ $? -eq 0 ]; then
    echo "✅ تم البناء بنجاح!"
    
    # 5. بناء جميع المشاريع
    cd /workspaces/bizai
    echo "🚀 بناء جميع المشاريع..."
    npm run build
else
    echo "❌ فشل البناء"
    echo "📋 الخطأ:"
    tail -30 final-build.log
    
    # الحل البديل: استخدم next مباشرة من node_modules المحلي
    echo "🔄 محاولة بديلة: استخدام next المحلي..."
    
    # تأكد من أن next مثبت محلياً في apps/web
    if [ ! -d "node_modules/next" ]; then
        npm install
    fi
    
    # استخدم next المحلي مباشرة
    ./node_modules/.bin/next build
fi