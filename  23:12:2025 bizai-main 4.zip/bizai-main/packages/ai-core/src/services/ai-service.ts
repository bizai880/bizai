import { AIRequest, AIResponse, AIModel, AIProvider, TokenUsage } from '../types';
import { OpenAIService } from '../providers/openai';
import { AnthropicService } from '../providers/anthropic';

export class AIService {
  private openai = new OpenAIService();
  private anthropic = new AnthropicService();
  
  private models: AIModel[] = [
    { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', provider: 'openai', maxTokens: 128000 },
    { id: 'gpt-4', name: 'GPT-4', provider: 'openai', maxTokens: 8192 },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', provider: 'openai', maxTokens: 16385 },
    { id: 'claude-3-opus', name: 'Claude 3 Opus', provider: 'anthropic', maxTokens: 200000 },
    { id: 'claude-3-sonnet', name: 'Claude 3 Sonnet', provider: 'anthropic', maxTokens: 200000 },
  ];

  getModels(): AIModel[] {
    return this.models;
  }

  getModelById(id: string): AIModel | undefined {
    return this.models.find(model => model.id === id);
  }

  async process(request: AIRequest): Promise<AIResponse> {
    const model = this.getModelById(request.model || 'gpt-3.5-turbo');
    
    if (!model) {
      throw new Error(`Model ${request.model} not found`);
    }

    const provider = model.provider as AIProvider;
    
    switch (provider) {
      case 'openai':
        return this.openai.generate(request);
      case 'anthropic':
        return this.anthropic.generate(request);
      default:
        throw new Error(`Provider ${provider} not supported`);
    }
  }

  async processBatch(requests: AIRequest[]): Promise<AIResponse[]> {
    const results: AIResponse[] = [];
    
    for (const request of requests) {
      try {
        const result = await this.process(request);
        results.push(result);
      } catch (error) {
        console.error(`Failed to process request:`, error);
        results.push({
          text: `Error: ${(error as Error).message}`,
          model: request.model || 'unknown',
          provider: 'error',
          tokensUsed: 0
        });
      }
    }
    
    return results;
  }
}

// Export singleton
export const aiService = new AIService();
