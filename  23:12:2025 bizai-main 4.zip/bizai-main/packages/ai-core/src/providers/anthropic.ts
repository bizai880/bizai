import { AIRequest, AIResponse } from '../types';

export class AnthropicService {
  async generate(request: AIRequest): Promise<AIResponse> {
    // Mock implementation
    console.log('Anthropic processing:', {
      model: request.model || 'claude-3-sonnet',
      promptLength: request.prompt.length
    });

    await new Promise(resolve => setTimeout(resolve, 150));

    return {
      text: `Claude response to: ${request.prompt.substring(0, 50)}...`,
      model: request.model || 'claude-3-sonnet',
      provider: 'anthropic',
      tokensUsed: Math.ceil(request.prompt.length / 3.5)
    };
  }
}
