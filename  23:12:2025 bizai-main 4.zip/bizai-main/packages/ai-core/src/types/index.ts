export interface AIModel {
  id: string;
  name: string;
  provider: string;
  maxTokens: number;
  supportsVision?: boolean;
}

export interface AIRequest {
  prompt: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
  stream?: boolean;
}

export interface AIResponse {
  text: string;
  model: string;
  provider: string;
  tokensUsed: number;
  finishReason?: string;
}

export interface AIError {
  code: string;
  message: string;
  provider: string;
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export type AIProvider = 'openai' | 'anthropic' | 'gemini' | 'local';
