# @bizai/shared

Shared TypeScript utilities and types for the BizAI Factory project.

## Installation
```bash
npm install @bizai/shared