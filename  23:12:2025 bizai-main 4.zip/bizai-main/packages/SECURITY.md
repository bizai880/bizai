# 🔐 Security Policy for @bizai Packages

## 📋 Overview

This document outlines security policies, procedures, and best practices for all packages under the `@bizai` npm organization. All packages are published as **private to the organization** by default.

## 🛡️ Security Standards

### Package Security
- **2FA Requirement**: All publishing operations require Two-Factor Authentication
- **Granular Tokens**: CI/CD uses scoped tokens with minimal permissions
- **Token Expiry**: Automated tokens have maximum 90-day lifespan
- **IP Restrictions**: Production tokens can be restricted to specific IP ranges

### Code Security
- **No Secrets in Code**: API keys, credentials, and secrets MUST NOT be committed
- **Environment Variables**: Sensitive data loaded via `.env` files (in `.gitignore`)
- **Dependency Scanning**: Regular `npm audit` and vulnerability scanning
- **Code Reviews**: All changes require security review before merging

## 🚨 Reporting Security Issues

### Contact
- **Primary**: Security team via organization settings on npmjs.com
- **Secondary**: Repository maintainers
- **Response Time**: Within 48 hours for critical issues

### What to Report
- API key exposure in published packages
- Dependency vulnerabilities affecting our packages
- Unauthorized access to organization
- Token compromise or leakage

### What NOT to Report
- Feature requests
- Non-security bugs
- Dependency updates without known vulnerabilities

## 🔄 Security Update Process

### Critical Vulnerabilities
1. **Immediate Action**: Create security advisory in npm
2. **Assessment**: Determine affected packages and versions
3. **Fix Development**: Create patch in private branch
4. **Testing**: Verify fix doesn't break dependencies
5. **Publishing**: Release patched versions
6. **Notification**: Alert organization members

### Regular Updates
- **Weekly**: Run `npm audit` across all packages
- **Monthly**: Review token access logs
- **Quarterly**: Security audit of all packages

## 🔐 Access Control

### Organization Roles
| Role | Permissions | Use Case |
|------|-------------|----------|
| **Owner** | Full control | Organization administrators |
| **Maintainer** | Publish packages, manage teams | Core developers |
| **Developer** | Read/Write to assigned packages | Team members |
| **Automation** | Scoped tokens for CI/CD | GitHub Actions, deployment |

### Token Policies
```bash
# Example: Creating secure CI token
npm token create \
  --read-write \
  --scope @bizai \
  --cidr 192.168.1.0/24 \
  --expiry 30d \
  --bypass-2fa

```
### npmignore files
```npmignore
# ملف .npmignore بسيط وفعّال

# 1. ملفات النظام والبيئة
.DS_Store
Thumbs.db
*.log
.env*
.env.local

# 2. مجلدات البناء
.next/
dist/
build/
out/
node_modules/

# 3. ملفات التطوير
.vscode/
.idea/
.turbo/
.vercel/

# 4. الاختبارات
**/*.test.*
**/*.spec.*
__tests__/
coverage/

# 5. ملفات Git
.git/

# 6. ملفات الوسائط الكبيرة
*.mp4
*.mov
*.zip

# ⭐ الملفات المهمة (ستبقى تلقائياً):
# - package.json
# - README.md
# - LICENSE
# - app/
# - components/
# - lib/
# - public/
# - next.config.js
# - tsconfig.json
