#!/bin/bash
# سكريبت تنظيف Cache الشامل
# تشغيل: bash clean-cache.sh أو npm run clean

echo "🧹 تنظيف Cache الشامل..."

# Turbo cache
echo "⚡ Turbo cache..."
rm -rf .turbo 2>/dev/null || true
rm -rf node_modules/.cache/turbo 2>/dev/null || true

# Next.js cache
echo "🔄 Next.js cache..."
find . -name ".next" -type d -exec rm -rf {} + 2>/dev/null || true

# npm cache
echo "📦 npm cache..."
rm -rf node_modules/.cache 2>/dev/null || true

# TypeScript cache
echo "📝 TypeScript cache..."
find . -name "tsconfig.tsbuildinfo" -type f -delete 2>/dev/null || true

# Build artifacts
echo "🏗️  Build artifacts..."
find . -name "dist" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "build" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "out" -type d -exec rm -rf {} + 2>/dev/null || true

# Log files
echo "📄 Log files..."
find . -name "*.log" -type f -delete 2>/dev/null || true

echo "✅ تم التنظيف بنجاح!"
