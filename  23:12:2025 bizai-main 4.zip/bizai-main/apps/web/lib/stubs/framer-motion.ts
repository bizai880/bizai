export const motion = {
  div: (props: any) => props.children,
  button: (props: any) => props.children,
  span: (props: any) => props.children
};

export const AnimatePresence = (props: any) => props.children;
export const motionValue = () => ({});
export const useMotionValue = () => ({});
export const useTransform = () => ({});
export const useSpring = () => ({});
export const useAnimation = () => ({});
export const animate = () => ({});
