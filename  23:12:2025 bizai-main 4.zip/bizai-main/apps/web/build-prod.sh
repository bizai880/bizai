#!/bin/bash
# سكريبت البناء النهائي مع Turbopack
cd /workspaces/bizai/apps/web
export NODE_OPTIONS="--max-old-space-size=8192"
export TURBOPACK=1

echo "🏗️  بدء البناء مع Turbopack..."
echo "📊 الذاكرة: $NODE_OPTIONS"
echo "⚡ Turbopack: مفعل"

# تنظيف الذاكرة المؤقتة
rm -rf .next 2>/dev/null || true
rm -rf node_modules/.cache 2>/dev/null || true

# بناء مع سجل تفصيلي
exec npx next build --turbopack 2>&1 | tee build-output.log
