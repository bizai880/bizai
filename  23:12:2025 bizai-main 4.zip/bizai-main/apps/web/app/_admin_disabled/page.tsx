'use client';

import { useEffect, useState } from 'react';

// Mock auth hook for build
function useMockAuth() {
  return {
    user: { name: 'Admin', role: 'admin' },
    isAuthenticated: true,
  };
}

export default function AdminPage() {
  const { user, isAuthenticated } = useMockAuth();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(false);
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div style={{ padding: 20 }}>
        <h1>Access Denied</h1>
        <p>Please login to access the admin panel.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Admin Dashboard</h1>
      <p>Welcome, {user?.name}!</p>
      <div>
        <h3>Quick Stats</h3>
        <ul>
          <li>Total Users: 1,250</li>
          <li>Active Sessions: 45</li>
          <li>Storage Used: 2.4 GB</li>
        </ul>
      </div>
    </div>
  );
}
