'use client';

import { useParams } from 'next/navigation';

// Mock useAuth for build
function useMockAuth() {
  return {
    user: { name: 'Admin' },
    isAuthenticated: true
  };
}

export default function UserDetailPage() {
  const params = useParams();
  const userId = params.id as string;
  const { isAuthenticated } = useMockAuth();

  if (!isAuthenticated) {
    return <div>Please login</div>;
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>User Details</h1>
      <p>User ID: {userId}</p>
      <div style={{ marginTop: 20 }}>
        <p>Name: John Doe</p>
        <p>Email: john@example.com</p>
        <p>Role: Administrator</p>
        <p>Status: Active</p>
      </div>
    </div>
  );
}
