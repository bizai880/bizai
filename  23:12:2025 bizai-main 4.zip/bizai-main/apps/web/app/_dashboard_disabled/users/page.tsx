'use client';

import { useState, useEffect } from 'react';

// Mock useAuth for build
function useMockAuth() {
  return {
    user: { name: 'John Doe', role: 'admin' },
    isAuthenticated: true,
    isLoading: false
  };
}

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'inactive';
}

export default function UsersPage() {
  const { user: authUser, isAuthenticated, isLoading } = useMockAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock data
    const mockUsers: User[] = [
      { id: '1', name: 'John Doe', email: 'john@example.com', role: 'admin', status: 'active' },
      { id: '2', name: 'Jane Smith', email: 'jane@example.com', role: 'user', status: 'active' },
      { id: '3', name: 'Bob Johnson', email: 'bob@example.com', role: 'user', status: 'inactive' },
      { id: '4', name: 'Alice Brown', email: 'alice@example.com', role: 'user', status: 'active' },
    ];
    
    setTimeout(() => {
      setUsers(mockUsers);
      setLoading(false);
    }, 500);
  }, []);

  if (isLoading) {
    return <div style={{ padding: 20 }}>Checking authentication...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div style={{ padding: 20 }}>
        <h1>Access Denied</h1>
        <p>Please login to view this page.</p>
      </div>
    );
  }

  if (loading) {
    return <div style={{ padding: 20 }}>Loading users...</div>;
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>User Management</h1>
      <p>Welcome, {authUser.name}!</p>
      
      <div style={{ marginTop: 20 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#f5f5f5' }}>
              <th style={{ padding: '10px', textAlign: 'left', border: '1px solid #ddd' }}>Name</th>
              <th style={{ padding: '10px', textAlign: 'left', border: '1px solid #ddd' }}>Email</th>
              <th style={{ padding: '10px', textAlign: 'left', border: '1px solid #ddd' }}>Role</th>
              <th style={{ padding: '10px', textAlign: 'left', border: '1px solid #ddd' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td style={{ padding: '10px', border: '1px solid #ddd' }}>{user.name}</td>
                <td style={{ padding: '10px', border: '1px solid #ddd' }}>{user.email}</td>
                <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                  <span style={{
                    padding: '4px 8px',
                    borderRadius: '4px',
                    background: user.role === 'admin' ? '#e3f2fd' : '#f5f5f5',
                    color: user.role === 'admin' ? '#1976d2' : '#666'
                  }}>
                    {user.role}
                  </span>
                </td>
                <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                  <span style={{
                    padding: '4px 8px',
                    borderRadius: '4px',
                    background: user.status === 'active' ? '#e8f5e9' : '#ffebee',
                    color: user.status === 'active' ? '#2e7d32' : '#c62828'
                  }}>
                    {user.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
