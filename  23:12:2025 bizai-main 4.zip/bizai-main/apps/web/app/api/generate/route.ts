import { NextRequest, NextResponse } from 'next/server';

// Simple API route without zod dependency
export async function POST(request: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      message: 'Generate API is working (zod stub)',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Internal server error'
    }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  return NextResponse.json({
    endpoint: 'generate',
    method: 'POST',
    description: 'Generate content API'
  });
}
