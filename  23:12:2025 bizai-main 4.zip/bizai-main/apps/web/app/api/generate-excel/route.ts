import { NextRequest, NextResponse } from 'next/server';
 
// Use Node.js runtime for heavy operations
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
 
interface ExcelGenerationRequest {
  templateType: 'sales' | 'tracking' | 'analytics';
  data: Record<string, any>[];
  options?: {
    includeCharts?: boolean;
    theme?: 'light' | 'dark';
    language?: 'ar' | 'en';
  };
}
 
export async function POST(request: NextRequest) {
  try {
    const body: ExcelGenerationRequest = await request.json();
    const { templateType, data, options = {} } = body;
 
    // Validate input
    if (!templateType || !data || !Array.isArray(data)) {
      return NextResponse.json(
        { error: 'Invalid request body' },
        { status: 400 }
      );
    }
 
    // Dynamic import ExcelJS only when needed (reduces initial bundle)
    const ExcelJS = (await import('exceljs')).default;
 
    const workbook = new ExcelJS.Workbook();
 
    // Set workbook properties
    workbook.creator = 'BizAI Factory';
    workbook.lastModifiedBy = 'BizAI System';
    workbook.created = new Date();
    workbook.modified = new Date();
 
    // Create worksheet based on template type
    const worksheet = workbook.addWorksheet(getSheetName(templateType, options.language));
 
    // Apply template-specific configuration
    switch (templateType) {
      case 'sales':
        configureSalesTemplate(worksheet, data, options);
        break;
      case 'tracking':
        configureTrackingTemplate(worksheet, data, options);
        break;
      case 'analytics':
        configureAnalyticsTemplate(worksheet, data, options);
        break;
      default:
        throw new Error('Unknown template type');
    }
 
    // Generate buffer
    const buffer = await workbook.xlsx.writeBuffer();
 
    // Return file with proper headers
    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${templateType}-report-${Date.now()}.xlsx"`,
        'Cache-Control': 'no-store, max-age=0',
      },
    });
 
  } catch (error) {
    console.error('Excel generation error:', error);
 
    return NextResponse.json(
      { 
        error: 'Failed to generate Excel file',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
 
// Helper functions
function getSheetName(templateType: string, language: string = 'ar'): string {
  const names = {
    sales: { ar: 'تقرير المبيعات', en: 'Sales Report' },
    tracking: { ar: 'تتبع العملاء', en: 'Customer Tracking' },
    analytics: { ar: 'تحليل الأداء', en: 'Performance Analytics' },
  };
 
  return names[templateType as keyof typeof names]?.[language as 'ar' | 'en'] || 'Report';
}
 
function configureSalesTemplate(
  worksheet: any,
  data: Record<string, any>[],
  options: any
) {
  // Define columns
  worksheet.columns = [
    { header: 'التاريخ', key: 'date', width: 15 },
    { header: 'المنتج', key: 'product', width: 25 },
    { header: 'الكمية', key: 'quantity', width: 12 },
    { header: 'السعر', key: 'price', width: 15 },
    { header: 'الإجمالي', key: 'total', width: 15 },
  ];
 
  // Style header row
  worksheet.getRow(1).font = { bold: true, size: 12 };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: options.theme === 'dark' ? 'FF1F2937' : 'FF3B82F6' },
  };
  worksheet.getRow(1).font.color = { argb: 'FFFFFFFF' };
 
  // Add data
  data.forEach((row) => {
    worksheet.addRow(row);
  });
 
  // Add totals row
  const lastRow = worksheet.rowCount + 1;
  worksheet.getCell(`E${lastRow}`).value = {
    formula: `SUM(E2:E${lastRow - 1})`,
  };
  worksheet.getCell(`E${lastRow}`).font = { bold: true };
 
  // Apply borders
  worksheet.eachRow((row: any) => {
    row.eachCell((cell: any) => {
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' },
      };
    });
  });
 
  // Add chart if requested
  if (options.includeCharts) {
    // Chart implementation would go here
  }
}
 
function configureTrackingTemplate(
  worksheet: any,
  data: Record<string, any>[],
  options: any
) {
  worksheet.columns = [
    { header: 'العميل', key: 'customer', width: 25 },
    { header: 'الحالة', key: 'status', width: 15 },
    { header: 'آخر تفاعل', key: 'lastInteraction', width: 20 },
    { header: 'الملاحظات', key: 'notes', width: 40 },
  ];
 
  // Style header
  worksheet.getRow(1).font = { bold: true, size: 12 };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF8B5CF6' },
  };
  worksheet.getRow(1).font.color = { argb: 'FFFFFFFF' };
 
  // Add data with conditional formatting
  data.forEach((row, index) => {
    const addedRow = worksheet.addRow(row);
 
    // Color code status
    const statusCell = addedRow.getCell('status');
    if (row.status === 'نشط') {
      statusCell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF10B981' },
      };
    } else if (row.status === 'معلق') {
      statusCell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFF59E0B' },
      };
    }
  });
}
 
function configureAnalyticsTemplate(
  worksheet: any,
  data: Record<string, any>[],
  options: any
) {
  worksheet.columns = [
    { header: 'المؤشر', key: 'metric', width: 25 },
    { header: 'القيمة', key: 'value', width: 15 },
    { header: 'التغيير', key: 'change', width: 15 },
    { header: 'الاتجاه', key: 'trend', width: 15 },
  ];
 
  // Style header
  worksheet.getRow(1).font = { bold: true, size: 12 };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF10B981' },
  };
  worksheet.getRow(1).font.color = { argb: 'FFFFFFFF' };
 
  // Add data
  data.forEach((row) => {
    const addedRow = worksheet.addRow(row);
 
    // Format change percentage
    const changeCell = addedRow.getCell('change');
    if (typeof row.change === 'number') {
      changeCell.numFmt = '0.00%';
      changeCell.font = {
        color: { argb: row.change >= 0 ? 'FF10B981' : 'FFEF4444' },
      };
    }
  });
}