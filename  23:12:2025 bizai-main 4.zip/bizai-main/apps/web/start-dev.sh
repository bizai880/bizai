#!/bin/bash
# سكريبت بدء التطوير مع Turbopack
cd /workspaces/bizai/apps/web
export NODE_OPTIONS="--max-old-space-size=4096"
export TURBOPACK=1

echo "🚀 بدء Next.js مع Turbopack..."
echo "📊 الذاكرة: $NODE_OPTIONS"
echo "⚡ Turbopack: مفعل"

# تشغيل next dev مع مراقبة الذاكرة
exec npx next dev --turbopack --port=3000 --hostname=0.0.0.0
