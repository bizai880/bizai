// Main entry point
export const version = "1.0.0";
console.log("Build successful!");
