"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateExcel = void 0;
var generateExcel = function () {
    return 'Excel generated';
};
exports.generateExcel = generateExcel;
