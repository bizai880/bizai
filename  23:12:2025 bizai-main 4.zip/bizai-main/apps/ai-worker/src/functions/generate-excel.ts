export const generateExcel = (): string => {
    return 'Excel generated';
};
