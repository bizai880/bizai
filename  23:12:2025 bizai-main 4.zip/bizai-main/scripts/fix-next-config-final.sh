#!/bin/bash

echo "🔧 إصلاح next.config.js نهائياً..."

cd /workspaces/bizai/apps/web

# 1. حذف next.config.js المعطوب
rm -f next.config.js next.config.mjs next.config.cjs 2>/dev/null || true

# 2. إنشاء next.config.js جديد صحيح 100%
cat > next.config.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  // الإعدادات الأساسية
  reactStrictMode: true,
  
  // SWC minification - تم تصحيحه من swMinify إلى swcMinify
  swcMinify: true,
  
  // التعامل مع الأخطاء
  typescript: {
    ignoreBuildErrors: false,  // تغيير إلى false بعد إصلاح جميع الأخطاء
  },
  
  eslint: {
    ignoreDuringBuilds: false, // تغيير إلى false بعد إصلاح جميع الأخطاء
  },
  
  // الصور
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  
  // إعدادات التصيير
  output: 'standalone',
  
  // إعدادات headers للأمان
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ]
  },
  
  // إعدادات experimental صحيحة
  experimental: {
    serverActions: {
      enabled: true,
      allowedOrigins: ['localhost:3000'],
    },
  },
}

module.exports = nextConfig
EOF

# 3. بديل: إنشاء ملف أبسط إذا كان الملف أعلاه معقداً
cat > next.config.simple.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    unoptimized: true,
  },
}

module.exports = nextConfig
EOF

# 4. تحقق من صحة الملف
echo "🔍 التحقق من صحة next.config.js..."
node -c next.config.js && echo "✅ الملف صالح" || {
  echo "⚠️ الملف به أخطاء، استخدام النسخة البسيطة..."
  cp next.config.simple.js next.config.js
}

# 5. تنظيف cache
echo "🧹 تنظيف cache..."
rm -rf .next 2>/dev/null || true

# 6. تحديث package.json إذا كان فيه next build script خاطئ
if [ -f "package.json" ]; then
  sed -i 's/"build": "next build.*"/"build": "next build"/' package.json
fi

# 7. اختبار البناء
echo "🏗️ اختبار البناء..."
npm run build 2>&1 | tail -25

echo ""
echo "✅ تم إصلاح:"
echo "   1. swcMinify (بدلاً من swMinify)"
echo "   2. experimental.serverActions كـ object (بدلاً من boolean)"
echo "   3. إعدادات images الصحيحة"
echo ""
echo "🎉 جرب الآن: npm run build"