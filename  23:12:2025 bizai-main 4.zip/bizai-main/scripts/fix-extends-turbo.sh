#!/bin/bash

# إصلاح خطأ "extends" في turbo.json
cd /workspaces/bizai

echo "🔧 إصلاح خطأ 'extends' في turbo.json..."

# 1. إصلاح turbo.json في apps/web
if [ -f "apps/web/turbo.json" ]; then
    echo "📄 إصلاح apps/web/turbo.json..."
    cat > apps/web/turbo.json << 'EOF'
{
  "extends": ["//"],
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
EOF
fi

# 2. إصلاح أو إنشاء turbo.json الرئيسي
echo "📄 إنشاء/إصلاح turbo.json الرئيسي..."
cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**", "build/**"]
    },
    "dev": {
      "cache": false
    },
    "lint": {
      "outputs": []
    },
    "test": {
      "outputs": []
    }
  }
}
EOF

# 3. تحديث package.json scripts
echo "🔧 تحديث package.json scripts..."
if [ -f "package.json" ]; then
    # إنشاء نسخة احتياطية
    cp package.json package.json.backup
    
    # تحقق مما إذا كان jq متاحاً
    if command -v jq &> /dev/null; then
        jq '.scripts.build = "turbo build"' package.json > package.json.tmp && mv package.json.tmp package.json
    else
        # استخدام sed كبديل
        sed -i 's/"build":.*/"build": "turbo build",/' package.json
    fi
fi

echo "✅ تم الإصلاح! جرب الآن: npm run build"