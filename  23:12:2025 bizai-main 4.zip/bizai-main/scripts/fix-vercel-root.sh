#!/bin/bash

echo "🎯 الحل الأفضل: إنشاء vercel.json داخل apps/web"

cd /workspaces/bizai

# 1. حذف vercel.json الرئيسي
rm -f vercel.json .vercelignore

# 2. إنشاء vercel.json داخل apps/web
cat > apps/web/vercel.json << 'EOF'
{
  "version": 2,
  "buildCommand": "npm run build",
  "outputDirectory": ".next",
  "installCommand": "npm install",
  "framework": "nextjs",
  "regions": ["iad1"],
  "github": {
    "silent": true
  },
  "public": false,
  "functions": {
    ".next/**/*.js": {
      "maxDuration": 60
    }
  }
}
EOF

# 3. إنشاء .vercelignore داخل apps/web
cat > apps/web/.vercelignore << 'EOF'
# تجاهل كل شيء
*

# استثناء الملفات الضرورية
!package.json
!next.config.js
!next-env.d.ts
!middleware.ts
!tailwind.config.js
!tsconfig.json
!app/**
!components/**
!lib/**
!hooks/**
!public/**
!.next

# تجاهل node_modules
node_modules
**/node_modules/**

# تجاهل environment files
.env*

# تجاهل ملفات system
.DS_Store
Thumbs.db

# تجاهل logs
*.log
EOF

# 4. رفع التغييرات
echo "📤 رفع التغييرات..."

git add apps/web/vercel.json apps/web/.vercelignore
git rm vercel.json .vercelignore 2>/dev/null || true

echo ""
echo "✅ تم! الآن Vercel سيتعامل مع apps/web كمشروع منفصل"
echo "🚀 Vercel سيبني من: apps/web/vercel.json"
echo ""
echo "أوامر الرفع:"
echo "git commit -m 'fix: نقل vercel.json إلى apps/web لحل مشكلة Next.js'"
echo "git push"