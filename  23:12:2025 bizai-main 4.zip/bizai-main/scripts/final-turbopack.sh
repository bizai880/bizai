#!/bin/bash
cd /workspaces/bizai

echo "🔧 بدء الإصلاح الشامل..."

# 1. أولاً، إصلاح turbo.json
echo "📄 إصلاح turbo.json..."
cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", "build/**", "lib/**", ".next/**", "!.next/cache/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "lint": {
      "outputs": []
    },
    "test": {
      "outputs": []
    }
  }
}
EOF

# 2. الانتقال إلى مجلد web وإصلاح مشكلة Turbopack
echo "🔄 الانتقال إلى apps/web..."
cd apps/web

# 3. إصلاح package.json scripts
echo "🔧 إصلاح package.json scripts في apps/web..."
cat > package.json.tmp << 'EOF'
{
  "name": "bizai-web",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "latest",
    "react": "latest",
    "react-dom": "latest"
  }
}
EOF

# دمج مع package.json الأصلي إذا كان موجوداً
if [ -f "package.json" ]; then
    # حفظ النسخة الأصلية
    cp package.json package.json.backup
    
    # دمج scripts
    if command -v jq &> /dev/null; then
        jq '.scripts = {
            "dev": "next dev",
            "build": "NODE_OPTIONS=\"--max-old-space-size=4096\" next build",
            "start": "next start",
            "lint": "next lint"
        }' package.json > package.json.new && mv package.json.new package.json
    else
        # استخدام sed كبديل
        sed -i '/"scripts":/,/}/d' package.json
        sed -i '/"scripts"/d' package.json
        echo '"scripts": {"dev": "next dev", "build": "NODE_OPTIONS=\"--max-old-space-size=4096\" next build", "start": "next start", "lint": "next lint"},' >> package.json
    fi
else
    mv package.json.tmp package.json
fi

# 4. إصلاح next.config.js (تعطيل Turbopack مؤقتاً)
echo "⚙️  إعداد next.config.js..."
if [ ! -f "next.config.js" ]; then
    cat > next.config.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  // تعطيل Turbopack مؤقتاً
  experimental: {
    // turbo: {} // تم التعليق مؤقتاً
  }
}

module.exports = nextConfig
EOF
else
    # تعطيل Turbopack في next.config.js الموجود
    sed -i '/turbo:/d' next.config.js 2>/dev/null || true
    sed -i '/experimental:/a\  // turbo: {} // تم التعليق مؤقتاً' next.config.js 2>/dev/null || true
fi

# 5. تنظيف الملفات المؤقتة
echo "🧹 تنظيف الملفات المؤقتة..."
rm -rf .next
rm -rf node_modules/.cache
rm -rf .turbo

# 6. العودة إلى المجلد الرئيسي
cd /workspaces/bizai

# 7. إصلاح package.json الرئيسي
echo "📦 إصلاح package.json الرئيسي..."
cat > package.json << 'EOF'
{
  "name": "bizai-factory",
  "version": "1.0.0",
  "private": true,
  "workspaces": [
    "apps/*",
    "packages/*"
  ],
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "lint": "turbo run lint",
    "clean": "rm -rf node_modules apps/*/node_modules packages/*/node_modules"
  },
  "devDependencies": {
    "turbo": "^2.6.3"
  }
}
EOF

# 8. إضافة ملفات package.json للمشاريع الأخرى لتجنب التحذيرات
echo "📝 إنشاء package.json للمشاريع الأخرى..."

# @bizai/ai-core
mkdir -p packages/ai-core
cat > packages/ai-core/package.json << 'EOF'
{
  "name": "@bizai/ai-core",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  }
}
EOF

# @bizai/database
mkdir -p packages/database
cat > packages/database/package.json << 'EOF'
{
  "name": "@bizai/database",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  }
}
EOF

# @bizai/shared
mkdir -p packages/shared
cat > packages/shared/package.json << 'EOF'
{
  "name": "@bizai/shared",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  }
}
EOF

# bizai-ai-worker
mkdir -p apps/ai-worker
cat > apps/ai-worker/package.json << 'EOF'
{
  "name": "bizai-ai-worker",
  "version": "1.0.0",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  }
}
EOF

# 9. إنشاء ملفات tsconfig.json بسيطة للمشاريع
for dir in packages/ai-core packages/database packages/shared apps/ai-worker; do
    cat > $dir/tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "es2015",
    "module": "commonjs",
    "outDir": "./dist",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
EOF
    
    # إنشاء مجلد src ومثال بسيط
    mkdir -p $dir/src
    cat > $dir/src/index.ts << 'EOF'
// Main entry point
export const version = "1.0.0";
console.log("Build successful!");
EOF
done

# 10. تنظيف شامل وإعادة تثبيت
echo "🔄 تنظيف وإعادة تثبيت..."
rm -rf node_modules
rm -rf apps/*/node_modules
rm -rf packages/*/node_modules

npm install

# 11. تشغيل البناء
echo "🔨 تشغيل البناء..."
npm run build 2>&1 | tee build.log

echo ""
echo "✅ تم الإصلاح!"
echo "📋 النتائج في build.log"