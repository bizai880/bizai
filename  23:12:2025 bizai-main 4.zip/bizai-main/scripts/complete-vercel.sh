#!/bin/bash
echo "🚀 رفع التغييرات النهائية لـ Vercel..."

cd /workspaces/bizai

# إضافة الملفات الضرورية
git add vercel.json .vercelignore apps/web/public/

# إذا كان هناك تغييرات في next.config.js
if [ -f "apps/web/next.config.js" ]; then
    git add apps/web/next.config.js
fi

# إذا قمت بتحديث package.json
if [ -f "package.json" ] && git diff --name-only package.json | grep -q "package.json"; then
    git add package.json
fi

# commit و push
git commit -m "feat: إعداد Vercel النهائي - إضافة vercel.json, public directory وإصلاحات البناء" || true
git push origin main

echo "✅ تم رفع التغييرات إلى GitHub!"
echo ""
echo "📌 Vercel سيبني تلقائياً بعد push"