#!/bin/bash
echo "🔧 إصلاح turbo.json للإصدار 2.0..."

if [ ! -f "turbo.json" ]; then
    echo "❌ ملف turbo.json غير موجود"
    exit 1
fi

# احفظ نسخة احتياطية
cp turbo.json turbo.json.backup

# استبدل pipeline بـ tasks
sed -i 's/"pipeline"/"tasks"/g' turbo.json

# أصلح dependsOn (خطأ إملائي)
sed -i 's/"dependson"/"dependsOn"/gI' turbo.json

# تحقق من JSON صحة
if node -e "JSON.parse(require('fs').readFileSync('turbo.json'))"; then
    echo "✅ turbo.json صالح الآن"
    
    # جرب البناء
    echo "🏗️  تجربة البناء..."
    npm run build 2>&1 | grep -i "error\|failed\|success" || echo "✅ يعمل!"
else
    echo "❌ turbo.json لا يزال تالفاً"
    echo "📋 استخدم هذه النسخة:"
    cat << 'TURBO_EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "tasks": {
    "build": { "outputs": [".next/cache/**", "dist/**"] },
    "dev": { "cache": false, "persistent": true },
    "lint": { "dependsOn": ["^build"] },
    "test": { "dependsOn": ["build"], "inputs": ["src/**/*.tsx", "src/**/*.ts", "test/**/*.ts", "test/**/*.tsx"] },
    "clean": { "cache": false },
    "type-check": { "dependsOn": ["^build"] }
  }
}
TURBO_EOF
fi