#!/bin/bash
echo "🔒 بدء تحسين أمان المشروع..."

# 1. تحديث npm نفسه
npm install -g npm@latest

# 2. الإصلاح التلقائي
echo "🔄 تشغيل npm audit fix..."
npm audit fix || echo "⚠️ بعض الإصلاحات تحتاج مراجعة يدوية"

# 3. تحديث الحزم
echo "📦 تحديث الحزم..."
npx npm-check-updates --target minor -u
npm install

# 4. إضافة overrides إذا استمرت مشكلة tmp
if grep -q "tmp" package-lock.json && [ ! -f "package.json.bak" ]; then
    echo "⚙️ إضافة overrides لـ tmp..."
    cp package.json package.json.bak
    node -e "
        const pkg = require('./package.json');
        pkg.overrides = { ...pkg.overrides, 'tmp': '^0.2.1' };
        require('fs').writeFileSync('package.json', JSON.stringify(pkg, null, 2));
    "
    npm install
fi

# 5. التحقق النهائي
echo "✅ التحقق النهائي..."
npm audit --audit-level=high

echo "📊 النتائج:"
npm audit --json | grep -A5 '"vulnerabilities"'