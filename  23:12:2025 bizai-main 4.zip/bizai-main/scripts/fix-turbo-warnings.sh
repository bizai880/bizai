#!/bin/bash

echo "🔧 إصلاح إعدادات Turbo..."

cd /workspaces/bizai

# 1. تحديث turbo.json
echo "📝 تحديث turbo.json..."
cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "outputs": ["dist/**", ".next/**", "!.next/cache/**"],
      "dependsOn": ["^build"],
      "inputs": ["src/**/*", "public/**/*", "package.json", "tsconfig.json"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "lint": {
      "outputs": []
    },
    "test": {
      "outputs": []
    }
  }
}
EOF

# 2. تنظيف cache Turbo
echo "🧹 تنظيف cache Turbo..."
rm -rf .turbo node_modules/.cache/turbo 2>/dev/null || true

# 3. إضافة ملف .turboignore
echo "📝 إنشاء .turboignore..."
cat > .turboignore << 'EOF'
# تجاهل الملفات المؤقتة
.next/cache/
node_modules/
dist/
*.log
*.tmp
*.temp
EOF

# 4. تحديث package.json الرئيسي
echo "📦 تحديث package.json الرئيسي..."
if [ -f "package.json" ]; then
  # إضافة scripts لـ turbo
  cat > package.json << 'EOF'
{
  "name": "bizai-factory",
  "version": "1.0.0",
  "private": true,
  "workspaces": ["apps/*"],
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "lint": "turbo run lint",
    "clean": "turbo run clean",
    "clean:full": "rm -rf node_modules apps/*/node_modules .turbo"
  },
  "devDependencies": {
    "turbo": "^2.6.3"
  }
}
EOF
fi

# 5. اختبار Turbo
echo "🧪 اختبار Turbo..."
npx turbo run build --dry=json 2>&1 | head -5

# 6. البناء مع Turbo
echo "🏗️ البناء باستخدام Turbo..."
npm run build 2>&1 | tail -10

echo ""
echo "✅ تم إصلاح Turbo!"
echo "📊 البناء الآن يعمل بنجاح مع:"
echo "   • Next.js (web) - ✅"
echo "   • AI Worker - ✅"
echo "   • Turbo Build System - ✅"