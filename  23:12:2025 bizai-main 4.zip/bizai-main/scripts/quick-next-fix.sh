#!/bin/bash
# quick-next-fix.sh

cd /workspaces/bizai

# 1. حذف node_modules
rm -rf node_modules apps/web/node_modules

# 2. إعادة التثبيت
npm install --legacy-peer-deps

# 3. تثبيت next في apps/web
cd apps/web
npm install next react react-dom --save --legacy-peer-deps

# 4. إصلاح ملفات next المفقودة
mkdir -p node_modules/next/dist/server
mkdir -p node_modules/next/dist/lib

cat > node_modules/next/dist/server/htmlescape.js << 'EOF'
module.exports = require('next/dist/server/htmlescape');
EOF

cat > node_modules/next/dist/lib/is-error.js << 'EOF'
module.exports = require('next/dist/lib/is-error');
EOF

# 5. البناء
npm run build

echo "✅ تم!"