#!/bin/bash
echo "🚀 بدء تثبيت Node.js و npm..."

# دالة للتحقق
check_install() {
    if command -v node &> /dev/null && command -v npm &> /dev/null; then
        echo "✅ Node.js: $(node --version)"
        echo "✅ npm: $(npm --version)"
        return 0
    fi
    return 1
}

# تحقق إذا كان مثبتاً بالفعل
if check_install; then
    echo "✅ Node.js و npm مثبتان بالفعل"
    exit 0
fi

# المحاولة 1: استخدام nvm (الأفضل)
echo "🔧 المحاولة 1: تثبيت عبر nvm..."
if ! command -v nvm &> /dev/null; then
    echo "📦 تحميل nvm..."
    if command -v curl &> /dev/null; then
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
    elif command -v wget &> /dev/null; then
        wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
    fi
    
    # تحميل nvm
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
fi

if command -v nvm &> /dev/null; then
    nvm install 20
    nvm use 20
    if check_install; then exit 0; fi
fi

# المحاولة 2: تثبيت مباشر عبر apt (لـDebian/Ubuntu)
echo "🔧 المحاولة 2: تثبيت عبر apt..."
if command -v apt-get &> /dev/null; then
    echo "📦 إعداد مستودع NodeSource..."
    if command -v curl &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    elif command -v wget &> /dev/null; then
        wget -q https://deb.nodesource.com/setup_20.x -O /tmp/nodesource_setup.sh
        sudo bash /tmp/nodesource_setup.sh
    fi
    
    sudo apt-get update
    sudo apt-get install -y nodejs
    
    if check_install; then exit 0; fi
fi

# المحاولة 3: تثبيت عبر apk (لـAlpine)
echo "🔧 المحاولة 3: تثبيت عبر apk..."
if command -v apk &> /dev/null; then
    apk update
    apk add nodejs npm
    
    if check_install; then exit 0; fi
fi

# المحاولة 4: تثبيت يدوي
echo "🔧 المحاولة 4: تثبيت يدوي..."
cd /tmp
echo "📦 تحميل Node.js يدوياً..."
if command -v curl &> /dev/null; then
    curl -L https://nodejs.org/dist/v20.18.0/node-v20.18.0-linux-x64.tar.xz -o node.tar.xz
elif command -v wget &> /dev/null; then
    wget https://nodejs.org/dist/v20.18.0/node-v20.18.0-linux-x64.tar.xz -O node.tar.xz
fi

if [ -f "node.tar.xz" ]; then
    tar -xf node.tar.xz
    cd node-v20.18.0-linux-x64
    sudo cp -r bin/* /usr/local/bin/
    sudo cp -r lib/* /usr/local/lib/
    sudo cp -r include/* /usr/local/include/
    
    if check_install; then exit 0; fi
fi

echo "❌ فشل جميع محاولات التثبيت"
echo "🔍 تشخيص النظام:"
uname -a
cat /etc/os-release 2>/dev/null || echo "لا يمكن تحديد نظام التشغيل"
exit 1