#!/bin/bash
cd /workspaces/bizai/apps/web

echo "🔧 إصلاح تضارب App Router و Pages Router..."

# 1. حذف أحد الملفين المتعارضين
echo "📂 حذف ملفات متعارضة..."
if [ -f "app/page.tsx" ] && [ -f "pages/index.tsx" ]; then
    echo "⚠️  يوجد ملفان متعارضان، اختيار App Router (أحدث)..."
    
    # حذف Pages Router والاحتفاظ بـ App Router
    rm -rf pages
    
    # تأكيد الحذف
    echo "✅ تم حذف مجلد pages والاحتفاظ بـ app"
fi

# 2. أو العكس: إذا أردت Pages Router
# echo "اختيار Pages Router..."
# rm -rf app
# mkdir -p pages

# 3. التأكد من وجود بنية صحيحة
echo "📁 إنشاء بنية App Router صحيحة..."
if [ ! -d "app" ]; then
    mkdir -p app
fi

# 4. إنشاء ملفات App Router الأساسية
echo "📄 إنشاء ملفات App Router..."

# صفحة رئيسية
cat > app/page.tsx << 'EOF'
export default function HomePage() {
  return (
    <main style={{ 
      padding: '2rem', 
      fontFamily: 'system-ui',
      maxWidth: '1200px',
      margin: '0 auto'
    }}>
      <h1>🚀 BizAI Platform</h1>
      <p>Next.js 15 with App Router</p>
      
      <div style={{ marginTop: '2rem', padding: '1rem', background: '#f5f5f5', borderRadius: '8px' }}>
        <h3>System Information:</h3>
        <ul>
          <li>Next.js: 15.5.9</li>
          <li>Node.js: {process.version}</li>
          <li>Build Time: {new Date().toLocaleString()}</li>
        </ul>
      </div>
      
      <div style={{ marginTop: '2rem' }}>
        <h3>Quick Links:</h3>
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <a href="/api/health" style={{ padding: '0.5rem 1rem', background: '#0070f3', color: 'white', borderRadius: '4px', textDecoration: 'none' }}>
            API Health
          </a>
          <a href="/dashboard" style={{ padding: '0.5rem 1rem', background: '#7928ca', color: 'white', borderRadius: '4px', textDecoration: 'none' }}>
            Dashboard
          </a>
        </div>
      </div>
    </main>
  )
}
EOF

# Layout
cat > app/layout.tsx << 'EOF'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'BizAI - Next.js 15',
  description: 'AI Platform built with Next.js 15',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header style={{ padding: '1rem', borderBottom: '1px solid #eaeaea' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between' }}>
            <h2 style={{ margin: 0 }}>BizAI</h2>
            <nav>
              <a href="/" style={{ marginRight: '1rem' }}>Home</a>
              <a href="/dashboard" style={{ marginRight: '1rem' }}>Dashboard</a>
              <a href="/api/health">API</a>
            </nav>
          </div>
        </header>
        {children}
        <footer style={{ padding: '2rem', textAlign: 'center', borderTop: '1px solid #eaeaea', marginTop: '2rem' }}>
          <p>© 2024 BizAI. Built with Next.js 15</p>
        </footer>
      </body>
    </html>
  )
}
EOF

# ملف CSS عالمي
cat > app/globals.css << 'EOF'
* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}

html,
body {
  max-width: 100vw;
  overflow-x: hidden;
}

a {
  color: inherit;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}
EOF

# صفحة dashboard
mkdir -p app/dashboard
cat > app/dashboard/page.tsx << 'EOF'
export default function DashboardPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>📊 Dashboard</h1>
      <p>This is the dashboard page.</p>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
        <div style={{ padding: '1rem', background: '#f0f0f0', borderRadius: '8px' }}>
          <h3>AI Models</h3>
          <p>Manage your AI models and configurations</p>
        </div>
        
        <div style={{ padding: '1rem', background: '#f0f0f0', borderRadius: '8px' }}>
          <h3>API Usage</h3>
          <p>Monitor your API requests and usage</p>
        </div>
        
        <div style={{ padding: '1rem', background: '#f0f0f0', borderRadius: '8px' }}>
          <h3>Settings</h3>
          <p>Configure your account and preferences</p>
        </div>
      </div>
    </main>
  )
}
EOF

# 5. إنشاء API routes في App Router
mkdir -p app/api/health
cat > app/api/health/route.ts << 'EOF'
import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    service: 'bizai-web',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    uptime: process.uptime()
  })
}
EOF

# 6. تحديث next.config.js
echo "⚙️  تحديث next.config.js لـ App Router..."
cat > next.config.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  
  // App Router فقط
  experimental: {
    // turbo: {}
  },
  
  // إعدادات أخرى
  images: {
    domains: [],
  },
  
  // زيادة مهلة البناء
  staticPageGenerationTimeout: 300,
}

module.exports = nextConfig
EOF

# 7. تنظيف الذاكرة المؤقتة
echo "🧹 تنظيف الذاكرة المؤقتة..."
rm -rf .next
rm -rf node_modules/.cache

# 8. البناء
echo "🔨 البناء مع App Router..."
npm run build 2>&1 | tee app-router-build.log

if [ $? -eq 0 ]; then
    echo "✅ تم البناء بنجاح مع App Router!"
    
    # 9. العودة والبناء الكامل
    cd /workspaces/bizai
    echo "🚀 بناء جميع المشاريع..."
    npm run build
else
    echo "❌ فشل البناء"
    echo "📋 الأخطاء:"
    tail -30 app-router-build.log
fi