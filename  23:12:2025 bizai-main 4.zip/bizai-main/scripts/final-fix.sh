#!/bin/bash
cd /workspaces/bizai

echo "🔧 الإصلاح النهائي لجميع التحذيرات..."

# 1. حذف ملف .npmrc القديم الذي يسبب المشكلة
rm -f .npmrc 2>/dev/null || true

# 2. إنشاء ملف .npmrc جديد صحيح
cat > .npmrc << 'EOF'
# إعدادات npm الصحيحة
engine-strict=true
legacy-peer-deps=true
save-exact=true
EOF

# 3. تحديث package.json لإضافة turbo كـ devDependency
echo "📦 تحديث package.json الرئيسي..."

if [ -f "package.json" ]; then
  # نسخة احتياطية
  cp package.json package.json.backup.$(date +%s)
  
  # إضافة turbo إلى devDependencies
  if ! grep -q '"turbo"' package.json; then
    # إذا كان هناك devDependencies، أضف turbo داخلها
    if grep -q '"devDependencies"' package.json; then
      sed -i '/"devDependencies": {/a\    "turbo": "^2.6.3",' package.json
    else
      # إذا لم يكن هناك devDependencies، أضف قسم جديد
      sed -i '/"scripts": {/i\  "devDependencies": {\n    "turbo": "^2.6.3"\n  },' package.json
    fi
  fi
fi

# 4. تثبيت turbo محلياً
echo "📥 تثبيت turbo محلياً..."
npm install turbo@^2.6.3 --save-dev --legacy-peer-deps

# 5. تحديث turbo.json
echo "📝 تحديث turbo.json..."
cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**", "!.next/cache/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
EOF

# 6. تحديث package.json في apps/web
echo "🔧 تحديث next في apps/web..."
cd apps/web

# تحديث next إلى إصدار آمن
if [ -f "package.json" ]; then
  sed -i 's/"next": "15\.0\.0"/"next": "^15.5.9"/' package.json 2>/dev/null || \
  sed -i 's/"next": "15\.[0-9]*\.[0-9]*"/"next": "^15.5.9"/' package.json
fi

cd ../..

# 7. إعادة التثبيت
echo "🔄 إعادة تثبيت الاعتماديات..."
rm -rf node_modules apps/*/node_modules 2>/dev/null || true
npm install --legacy-peer-deps

# 8. تحقق من التثبيت
echo "✅ التحقق من التثبيت..."
npm list turbo 2>/dev/null | grep turbo && echo "✅ Turbo مثبت محلياً" || echo "⚠️ Turbo غير مثبت"

# 9. اختبار البناء
echo "🏗️ اختبار البناء..."
npx turbo run build --dry 2>&1 | head -5

echo ""
echo "🎉 تم الإصلاح! جرب الآن:"
echo "   npm run build"