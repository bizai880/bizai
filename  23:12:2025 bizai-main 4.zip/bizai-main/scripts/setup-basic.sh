#!/bin/bash
# scripts/setup-basic.sh
# سكريبت تهيئة متكامل لـ Turborepo مع دعم جميع الأدوات

set -e  # توقف عند أول خطأ

echo "========================================"
echo "🚀  تهيئة مشروع BizAI Turborepo المتكامل"
echo "========================================"

# ============================================
# 1. التحقق من النظام والبيئة
# ============================================
echo "1. 🔍 التحقق من النظام..."
echo "   📅 التاريخ: $(date)"
echo "   🖥️  النظام: $(uname -srm)"
echo "   📂 المسار: $(pwd)"

# التحقق من إصدارات الأدوات الأساسية
check_version() {
    local tool=$1
    local version_cmd=$2
    if command -v $tool &> /dev/null; then
        echo "   ✅ $tool: $($version_cmd 2>/dev/null | head -1)"
    else
        echo "   ❌ $tool: غير مثبت"
        return 1
    fi
}

echo "   📦 إصدارات الأدوات:"
check_version "node" "node --version"
check_version "npm" "npm --version"
check_version "turbo" "turbo --version"
check_version "docker" "docker --version"
check_version "docker-compose" "docker-compose --version"

# ============================================
# 2. إعداد npm المثالي لـ Turborepo
# ============================================
echo "2. ⚙️  إعداد npm للتوربوريبو..."
npm config set registry https://registry.npmjs.org/
npm config set legacy-peer-deps true
npm config set audit false
npm config set fund false
npm config set progress true
npm config set prefer-offline true
npm config set maxsockets 3
npm config set fetch-retries 3
npm config set fetch-retry-mintimeout 10000
npm config set fetch-retry-maxtimeout 60000

# إعدادات خاصة بالبيئة
if [ -n "$GITPOD_WORKSPACE_URL" ]; then
    echo "   🐙 بيئة Gitpod مكتشفة"
    npm config set cache /workspace/.npm
elif [ -n "$CODESPACE_NAME" ]; then
    echo "   💻 بيئة GitHub Codespaces مكتشفة"
elif [ -n "$ONA_ENV" ]; then
    echo "   🤖 بيئة ONA مكتشفة"
else
    echo "   💼 بيئة تطوير محلية"
fi

# ============================================
# 3. تنظيف وتهيئة Turbo Cache
# ============================================
echo "3. 🧹 تنظيف وإعداد Turbo Cache..."
rm -rf .turbo /tmp/turbo-cache 2>/dev/null || true
mkdir -p /tmp/turbo-cache /workspace/.cache/turbo
export TURBO_CACHE_DIR="/tmp/turbo-cache"
export TURBO_TELEMETRY_DISABLED=1
export NEXT_TELEMETRY_DISABLED=1

# تنظيف node_modules القديمة إذا كانت كبيرة
if [ -d "node_modules" ] && [ $(du -s node_modules | cut -f1) -gt 500000 ]; then
    echo "   📦 تنظيف node_modules كبيرة..."
    rm -rf node_modules apps/*/node_modules packages/*/node_modules
fi

# ============================================
# 4. تثبيت Dependencies باستخدام Turbo
# ============================================
echo "4. 📦 تثبيت Dependencies..."
echo "   🔗 تثبيت dependencies الجذرية..."
npm install --no-audit --no-fund --legacy-peer-deps

# استخدام Turbo لتثبيت workspace dependencies
if command -v turbo &> /dev/null; then
    echo "   ⚡ استخدام Turbo للتثبيت المتوازي..."
    
    # تثبيت shared package أولاً
    if [ -f "packages/shared/package.json" ]; then
        echo "   📁 تثبيت @bizai/shared..."
        cd packages/shared
        npm install --no-audit --no-fund 2>/dev/null || true
        cd ../..
    fi
    
    # تثبيت apps باستخدام turbo
    echo "   📱 تثبيت applications..."
    turbo run build --filter=./apps/web --dry-run 2>/dev/null || true
    turbo run build --filter=./apps/ai-worker --dry-run 2>/dev/null || true
else
    echo "   ⚠️  Turbo غير مثبت، استخدام npm تقليدي..."
    for dir in apps/*/ packages/*/; do
        if [ -f "${dir}package.json" ]; then
            echo "   📦 تثبيت في: $(basename ${dir})"
            cd "${dir}"
            npm install --no-audit --no-fund 2>/dev/null || true
            cd ../..
        fi
    done
fi

# ============================================
# 5. إعداد ملفات Environment
# ============================================
echo "5. 📝 إعداد ملفات Environment..."
ENV_FILES_CREATED=0

# إنشاء .env.local إذا لم يوجد
if [ ! -f ".env.local" ]; then
    if [ -f ".env.local.example" ]; then
        cp .env.local.example .env.local
        echo "   ✅ تم إنشاء .env.local من النموذج"
        ENV_FILES_CREATED=$((ENV_FILES_CREATED + 1))
    else
        cat > .env.local << 'ENV_LOCAL'
# ===== إعدادات التطوير =====
NODE_ENV=development
NEXT_PUBLIC_APP_ENV=development

# ===== قاعدة البيانات =====
DATABASE_URL="postgresql://bizai_dev:dev_pass_123@localhost:5432/bizai_development"
DIRECT_URL="postgresql://bizai_dev:dev_pass_123@localhost:5432/bizai_development"

# ===== Redis =====
REDIS_URL="redis://localhost:6379"
REDIS_PASSWORD="dev_redis_pass"

# ===== NextAuth =====
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="dev_secret_$(openssl rand -hex 32)"

# ===== Supabase (اختياري) =====
# NEXT_PUBLIC_SUPABASE_URL="https://your-project.supabase.co"
# NEXT_PUBLIC_SUPABASE_ANON_KEY="your-anon-key"

# ===== AI APIs (اختياري) =====
# GROQ_API_KEY=""
# GITHUB_TOKEN=""

# ===== Vercel =====
VERCEL_URL="http://localhost:3000"
VERCEL_ENV="development"
ENV_LOCAL
        echo "   ✅ تم إنشاء .env.local جديد"
        ENV_FILES_CREATED=$((ENV_FILES_CREATED + 1))
    fi
else
    echo "   ✅ ملف .env.local موجود"
fi

# نسخ إلى apps/web إذا كان Next.js
if [ -d "apps/web" ] && [ -f ".env.local" ]; then
    cp .env.local apps/web/.env.local 2>/dev/null || true
    echo "   📁 نسخ .env.local إلى apps/web/"
fi

# ============================================
# 6. التحقق من البناء والسلامة
# ============================================
echo "6. 🔨 التحقق من سلامة المشروع..."

# فحص TypeScript
if [ -f "package.json" ] && grep -q '"type-check"' package.json; then
    echo "   📝 فحص TypeScript..."
    npm run type-check --dry-run 2>/dev/null || echo "   ℹ️  TypeScript check متاح"
fi

# فحص ESLint
if [ -f "package.json" ] && grep -q '"lint"' package.json; then
    echo "   ✨ فحص ESLint..."
    npm run lint --dry-run 2>/dev/null || echo "   ℹ️  ESLint متاح"
fi

# اختبار بناء shared package
if [ -f "packages/shared/package.json" ]; then
    echo "   📦 اختبار بناء shared package..."
    cd packages/shared
    npm run build --dry-run 2>/dev/null || true
    cd ../..
fi

# ============================================
# 7. إعداد Docker للتطوير
# ============================================
echo "7. 🐳 إعداد Docker للتطوير..."

# التحقق من Docker Compose
if command -v docker-compose &> /dev/null || command -v docker &> /dev/null; then
    # استخدام docker-compose.dev.yml إذا موجود
    if [ -f "docker-compose.dev.yml" ]; then
        echo "   📄 استخدام docker-compose.dev.yml"
        COMPOSE_FILE="docker-compose.dev.yml"
    elif [ -f "docker-compose.yml" ]; then
        echo "   📄 استخدام docker-compose.yml"
        COMPOSE_FILE="docker-compose.yml"
    fi
    
    if [ -n "$COMPOSE_FILE" ]; then
        echo "   🔍 اختبار تكوين Docker Compose..."
        docker-compose -f $COMPOSE_FILE config --quiet && echo "   ✅ التكوين صالح"
        
        # عرض الخدمات المتاحة
        SERVICES=$(docker-compose -f $COMPOSE_FILE config --services 2>/dev/null || echo "")
        if [ -n "$SERVICES" ]; then
            echo "   📋 الخدمات المتاحة:"
            echo "$SERVICES" | while read service; do
                echo "      • $service"
            done
        fi
    fi
else
    echo "   ⚠️  Docker غير مثبت"
fi

# ============================================
# 8. إنشاء Aliases وأوامر مساعدة
# ============================================
echo "8. ⚡ إنشاء أوامر مساعدة..."

# تحديد ملف bashrc المناسب
if [ -d "/home/gitpod" ]; then
    BASHRC_DIR="/home/gitpod/.bashrc.d"
    BASHRC_FILE="/home/gitpod/.bashrc"
elif [ -d "/home/node" ]; then
    BASHRC_DIR="/home/node/.bashrc.d"
    BASHRC_FILE="/home/node/.bashrc"
elif [ -d "/home/codespace" ]; then
    BASHRC_DIR="/home/codespace/.bashrc.d"
    BASHRC_FILE="/home/codespace/.bashrc"
else
    BASHRC_DIR="$HOME/.bashrc.d"
    BASHRC_FILE="$HOME/.bashrc"
fi

mkdir -p "$BASHRC_DIR"

cat > "$BASHRC_DIR/bizai-commands.sh" << 'BASHRC_EOF'
# أوامر مساعدة لمشروع BizAI Turborepo

# Aliases أساسية
alias biz-dev='cd /workspace && npm run dev:turbopack'
alias biz-build='cd /workspace && npm run build'
alias biz-clean='cd /workspace && npm run clean:all'
alias biz-docker='cd /workspace && npm run docker:dev'
alias biz-ona='cd /workspace && npm run ona:fix'
alias biz-vercel='cd /workspace && npm run vercel:preview'

# فحص الحالة
biz-status() {
    echo "=== 📊 حالة مشروع BizAI ==="
    echo "المسار: $(pwd)"
    echo "Node: $(node --version 2>/dev/null || echo 'غير مثبت')"
    echo "npm: $(npm --version 2>/dev/null || echo 'غير مثبت')"
    echo "Turbo: $(turbo --version 2>/dev/null || echo 'غير مثبت')"
    
    echo ""
    echo "=== 📁 هيكل المشروع ==="
    if [ -d "apps/web" ]; then
        echo "🌐 Next.js App:   موجود"
        cd apps/web
        echo "   Next: $(npm list next 2>/dev/null | grep next | head -1 | cut -d'@' -f2 || echo 'غير مثبت')"
        echo "   React: $(npm list react 2>/dev/null | grep react | head -1 | cut -d'@' -f2 || echo 'غير مثبت')"
        cd ../..
    fi
    
    if [ -d "apps/ai-worker" ]; then
        echo "🤖 AI Worker:     موجود"
    fi
    
    if [ -d "packages/shared" ]; then
        echo "📦 Shared Package: موجود"
    fi
    
    echo ""
    echo "=== 🐳 حالة Docker ==="
    if command -v docker &> /dev/null; then
        docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | head -5
    else
        echo "Docker غير قيد التشغيل"
    fi
}

# أوامر Turbo المساعدة
biz-turbo-help() {
    echo "=== ⚡ أوامر Turborepo ==="
    echo "npm run dev              # تطوير جميع المشاريع"
    echo "npm run dev:turbopack    # تطوير مع Turbopack"
    echo "npm run dev:web          # تطوير Next.js فقط"
    echo "npm run build            # بناء جميع المشاريع"
    echo "npm run build:web        # بناء Next.js فقط"
    echo "npm run lint             # lint جميع الملفات"
    echo "npm run type-check       # فحص TypeScript"
    echo "npm run clean            # تنظيف cache"
    echo ""
    echo "=== 🔧 أوامر DevOps ==="
    echo "npm run docker:dev       # تشغيل قواعد البيانات"
    echo "npm run gitpod:setup     # إعداد Gitpod"
    echo "npm run ona:fix          # إصلاح بالذكاء الاصطناعي"
    echo "npm run vercel:deploy    # نشر على Vercel"
}

# تشغيل Turbo مع cache محسن
biz-turbo() {
    TURBO_CACHE_DIR="/tmp/turbo-cache" turbo "$@"
}

echo "✅ تم تحميل أوامر BizAI. استخدم 'biz-status' للفحص."
BASHRC_EOF

# إضافة sourcing لـ bashrc
if ! grep -q "bizai-commands.sh" "$BASHRC_FILE" 2>/dev/null; then
    echo "source $BASHRC_DIR/bizai-commands.sh" >> "$BASHRC_FILE"
fi

# ============================================
# 9. الإنهاء وعرض النتائج
# ============================================
echo "9. ✅ الإنهاء..."

# جمع المعلومات للعرض
NODE_VERSION=$(node --version 2>/dev/null || echo "غير مثبت")
NPM_VERSION=$(npm --version 2>/dev/null || echo "غير مثبت")
TURBO_VERSION=$(turbo --version 2>/dev/null | head -1 || echo "غير مثبت")

echo ""
echo "========================================"
echo "🎉  تهيئة BizAI Turborepo اكتملت!"
echo "========================================"
echo ""
echo "📊  معلومات النظام:"
echo "   Node.js:    $NODE_VERSION"
echo "   npm:        $NPM_VERSION"
echo "   Turbo:      $TURBO_VERSION"
echo "   ملفات .env: $ENV_FILES_CREATED تم إنشاؤها"
echo ""
echo "🚀  أوامر البدء السريع:"
echo "   1. npm run dev:turbopack    # تطوير مع Turbopack"
echo "   2. npm run docker:dev       # قواعد البيانات"
echo "   3. biz-status              # فحص الحالة"
echo ""
echo "🔗  الوصول للتطبيقات:"
if [ -n "$GITPOD_WORKSPACE_URL" ]; then
    echo "   Next.js:    https://3000-${GITPOD_WORKSPACE_URL#https://}"
    echo "   AI Worker:  https://3001-${GITPOD_WORKSPACE_URL#https://}"
else
    echo "   Next.js:    http://localhost:3000"
    echo "   AI Worker:  http://localhost:3001"
    echo "   PostgreSQL: localhost:5432"
    echo "   Redis:      localhost:6379"
fi
echo ""
echo "⚡  نصائح سريعة:"
echo "   • استخدم 'biz-turbo-help' لرؤية جميع الأوامر"
echo "   • استخدم 'npm run ona:fix' لإصلاح المشاكل تلقائياً"
echo "   • استخدم 'npm run clean:install' لإعادة تثبيت نظيفة"
echo ""
echo "========================================"
echo "🕐  الوقت المستغرق: ~$(($SECONDS / 60)) دقيقة"
echo "========================================"

# تشغيل فحص الحالة النهائي
if command -v biz-status &> /dev/null; then
    biz-status
fi