#!/bin/bash
echo "🔍 التحقق النهائي قبل النشر على Vercel..."

cd /workspaces/bizai

echo "📋 الملفات المطلوبة للـ Vercel:"
echo "================================"

# 1. التحقق من vercel.json
if [ -f "vercel.json" ]; then
    echo "✅ vercel.json موجود"
    echo "   Build Command: $(grep '"buildCommand"' vercel.json | head -1)"
    echo "   Output Directory: $(grep '"outputDirectory"' vercel.json | head -1)"
else
    echo "❌ vercel.json مفقود!"
fi

# 2. التحقق من .vercelignore
if [ -f ".vercelignore" ]; then
    echo "✅ .vercelignore موجود"
else
    echo "❌ .vercelignore مفقود!"
fi

# 3. التحقق من public directory
if [ -d "apps/web/public" ]; then
    echo "✅ apps/web/public موجود"
    ls -la apps/web/public/
else
    echo "❌ apps/web/public مفقود!"
fi

# 4. التحقق من next.config.js
if [ -f "apps/web/next.config.js" ]; then
    echo "✅ apps/web/next.config.js موجود"
    if grep -q "output: 'standalone'" apps/web/next.config.js; then
        echo "   ✅ يحتوي على output: 'standalone'"
    else
        echo "   ⚠️  لا يحتوي على output: 'standalone'"
    fi
fi

# 5. التحقق من package.json scripts
if [ -f "package.json" ]; then
    if grep -q '"vercel-build"' package.json; then
        echo "✅ package.json يحتوي على vercel-build script"
    else
        echo "⚠️  package.json لا يحتوي على vercel-build script"
    fi
fi

echo ""
echo "🎯 الخطوات النهائية:"
echo "=================="
echo "1. ✅ البناء المحلي ناجح"
echo "2. 📤 رفع التغييرات إلى GitHub (git push)"
echo "3. ⚙️  إضافة Environment Variables في Vercel Dashboard"
echo "4. 🔧 في Vercel Project Settings:"
echo "   - Build Command: cd apps/web && npm run build"
echo "   - Output Directory: apps/web/.next"
echo "5. 🚀 Vercel سيبني تلقائياً"
echo ""
echo "💡 ملاحظة: التحذيرات عن المفاتيح ستظهر حتى تضيفها في Environment Variables"