#!/bin/bash

echo "🔄 إعادة تعيين الـ Codespace بالكامل..."

# 1. إزالة أي تثبيتات قديمة
sudo apt-get remove --purge -y nodejs npm
sudo rm -rf /usr/local/lib/node_modules
sudo rm -rf /usr/local/bin/npm
sudo rm -rf /usr/local/bin/node

# 2. تحديث النظام
sudo apt-get update -y
sudo apt-get upgrade -y

# 3. تثبيت المتطلبات الأساسية
sudo apt-get install -y \
    curl \
    wget \
    git \
    build-essential \
    ca-certificates \
    gnupg \
    lsb-release

# 4. تثبيت Node.js 20.x مباشرة
echo "⬢ تثبيت Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 5. تثبيت npm
sudo npm install -g npm@latest

# 6. التحقق من التثبيت
echo "✅ الإصدارات المثبتة:"
node --version
npm --version

# 7. الانتقال إلى المشروع
cd /workspaces/bizai

# 8. تنظيف المشروع
rm -rf node_modules
rm -rf apps/*/node_modules
rm -f package-lock.json

# 9. تثبيت الاعتماديات
npm install --legacy-peer-deps --force

# 10. تثبيت turbo عالمياً
npm install -g turbo

echo "🎉 تم إعادة التعيين بنجاح!"
echo "💻 يمكنك الآن استخدام:"
echo "   npm run dev    - لتشغيل بيئة التطوير"
echo "   npm run build  - للبناء"
echo "   npm test       - لتشغيل الاختبارات"