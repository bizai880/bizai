#!/bin/bash

echo "🔧 إصلاح Codespace وإعادة تثبيت Node.js/npm..."

# 1. إعادة تثبيت Node.js و npm
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get update
sudo apt-get install -y nodejs
sudo npm install -g npm@latest

# 2. التحقق من التثبيت
echo "📊 الإصدارات المثبتة:"
node --version
npm --version

# 3. إصلاح مشاكل Git
git config --global --add safe.directory /workspaces/bizai
git config --global --add safe.directory /workspaces/bizai/*
git config --global user.email "user@example.com"
git config --global user.name "BizAI User"

# 4. إصلاح مشاكل NPM
cd /workspaces/bizai
rm -rf node_modules
rm -rf package-lock.json
rm -rf apps/*/node_modules

# 5. إعادة تثبيت الاعتماديات
npm cache clean --force
npm install --legacy-peer-deps

# 6. إصلاح مشاكل TurboRepo
if [ -f "package.json" ]; then
    if grep -q "turbo" package.json; then
        npm install -g turbo
        npm run build -- --force || true
    fi
fi

# 7. إصلاح أذونات المجلدات
sudo chown -R $(whoami):$(whoami) /workspaces/bizai
sudo chmod -R 755 /workspaces/bizai

echo "✅ تم الانتهاء من الإصلاح!"