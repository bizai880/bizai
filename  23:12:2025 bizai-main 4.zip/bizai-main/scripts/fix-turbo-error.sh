#!/bin/bash

# سكريبت إصلاح خطأ pipeline/tasks في Turbo
# حفظ كـ: /workspaces/bizai/fix-turbo-error.sh
# ثم: chmod +x fix-turbo-error.sh && ./fix-turbo-error.sh

echo "🔧 إصلاح خطأ pipeline/tasks في turbo.json..."

# الانتقال للمجلد الرئيسي
cd /workspaces/bizai

# 1. إصلاح turbo.json في المجلد الرئيسي (إن وجد)
if [ -f "turbo.json" ]; then
    echo "📄 إصلاح turbo.json الرئيسي..."
    
    # إنشاء نسخة احتياطية
    cp turbo.json turbo.json.backup
    
    # استخدام sed لإصلاح pipeline إلى tasks
    sed -i 's/"pipeline":/"tasks":/g' turbo.json
    
    echo "✅ تم إصلاح turbo.json الرئيسي"
fi

# 2. إصلاح turbo.json في apps/web (إن وجد)
if [ -f "apps/web/turbo.json" ]; then
    echo "📄 إصلاح turbo.json في apps/web..."
    
    # إنشاء نسخة احتياطية
    cp apps/web/turbo.json apps/web/turbo.json.backup
    
    # إصلاح الملف باستخدام sed
    sed -i 's/"pipeline":/"tasks":/g' apps/web/turbo.json
    
    echo "✅ تم إصلاح turbo.json في apps/web"
fi

# 3. التحقق من جميع ملفات turbo.json في المشروع
echo "🔍 البحث عن جميع ملفات turbo.json..."
find . -name "turbo.json" -type f | while read file; do
    echo "   📍 وجد: $file"
    
    # التحقق مما إذا كان يحتوي على pipeline
    if grep -q '"pipeline":' "$file"; then
        echo "   ⚠️  يحتاج إصلاح: $file"
        
        # إنشاء نسخة احتياطية
        cp "$file" "${file}.backup"
        
        # إصلاح الملف
        sed -i 's/"pipeline":/"tasks":/g' "$file"
        
        echo "   ✅ تم إصلاح: $file"
    else
        echo "   ✓ سليم: $file"
    fi
done

# 4. إنشاء turbo.json صحيح إذا لم يكن موجوداً
echo "⚡ إنشاء ملف turbo.json صحيح إذا لزم..."
if [ ! -f "turbo.json" ]; then
    echo "📄 إنشاء turbo.json رئيسي جديد..."
    cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "lint": {
      "outputs": []
    },
    "test": {
      "outputs": []
    }
  }
}
EOF
fi

# 5. إصلاح package.json scripts إذا لزم
echo "🔧 تحديث scripts في package.json..."
if [ -f "package.json" ]; then
    # التحقق مما إذا كان build يستخدم turbo
    if grep -q '"build":.*turbo' package.json; then
        echo "✅ build script يستخدم turbo بالفعل"
    else
        echo "📝 تحديث build script لاستخدام turbo..."
        
        # إنشاء نسخة احتياطية
        cp package.json package.json.backup
        
        # تحديث باستخدام jq (إذا كان مثبتاً)
        if command -v jq &> /dev/null; then
            jq '.scripts.build = "turbo run build"' package.json > package.json.tmp && mv package.json.tmp package.json
        else
            # بديل بدون jq
            sed -i 's/"build":.*/"build": "turbo run build",/g' package.json
        fi
    fi
fi

# 6. تحديث إصدار Turbo إذا لزم
echo "📦 التحقق من إصدار Turbo..."
CURRENT_TURBO=$(npm list turbo 2>/dev/null | grep turbo | head -1 || echo "غير مثبت")
echo "   الإصدار الحالي: $CURRENT_TURBO"

# 7. تشغيل تنظيف الذاكرة المؤقتة
echo "🧹 تنظيف ذاكرة Turbo المؤقتة..."
npx turbo daemon stop 2>/dev/null || true
rm -rf node_modules/.cache/turbo 2>/dev/null || true
rm -rf .turbo 2>/dev/null || true

# 8. تشغيل build test
echo "🔨 اختبار البناء..."
if npx turbo run build --dry=json 2>&1 | grep -q "error"; then
    echo "⚠️  لا يزال هناك أخطاء، تحقق يدوياً"
else
    echo "✅ بناء جاف ناجح!"
fi

echo ""
echo "🎉 تم الانتهاء من الإصلاح!"
echo ""
echo "📋 ملخص التغييرات:"
echo "1. ✅ تم تغيير 'pipeline' إلى 'tasks' في جميع ملفات turbo.json"
echo "2. ✅ تم إنشاء نسخ احتياطية من الملفات المعدلة"
echo "3. ✅ تم تنظيف الذاكرة المؤقتة لـ Turbo"
echo ""
echo "🚀 جرب الآن:"
echo "   npm run build"
echo ""
echo "📄 إذا استمرت المشكلة، راجع:"
echo "   - turbo.json.backup (النسخة الأصلية)"
echo "   - docs: https://turbo.build/repo/docs/core-concepts/monorepos/tasks"