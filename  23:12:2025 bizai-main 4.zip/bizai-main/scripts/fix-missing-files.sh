#!/bin/bash

echo "🔧 إصلاح مشاكل المكونات المفقودة في Next.js..."

cd /workspaces/bizai/apps/web

# 1. إنشاء المكونات المفقودة
echo "📁 إنشاء المكونات المفقودة..."

# إنشاء مجلد components إذا لم يكن موجوداً
mkdir -p components/admin
mkdir -p components/users

# 2. إنشاء المكونات المطلوبة

# RecentActivities.tsx
cat > components/admin/RecentActivities.tsx << 'EOF'
export default function RecentActivities() {
    return (
        <div className="p-4 bg-white rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Recent Activities</h3>
            <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                        <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-blue-100 rounded-full"></div>
                            <div>
                                <p className="text-sm font-medium">Activity {i}</p>
                                <p className="text-xs text-gray-500">2 hours ago</p>
                            </div>
                        </div>
                        <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded">Completed</span>
                    </div>
                ))}
            </div>
        </div>
    );
}
EOF

# UserManagement.tsx
cat > components/admin/UserManagement.tsx << 'EOF'
export default function UserManagement() {
    const users = [
        { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin', status: 'Active' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'User', status: 'Active' },
        { id: 3, name: 'Bob Johnson', email: 'bob@example.com', role: 'User', status: 'Inactive' },
    ];

    return (
        <div className="p-4 bg-white rounded-lg shadow">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">User Management</h3>
                <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Add User
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {users.map((user) => (
                            <tr key={user.id}>
                                <td className="px-4 py-3 text-sm">{user.name}</td>
                                <td className="px-4 py-3 text-sm">{user.email}</td>
                                <td className="px-4 py-3 text-sm">
                                    <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">{user.role}</span>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                    <span className={`px-2 py-1 text-xs rounded ${user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                    <button className="text-blue-600 hover:text-blue-800 mr-3">Edit</button>
                                    <button className="text-red-600 hover:text-red-800">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
EOF

# BillingOverview.tsx
cat > components/admin/BillingOverview.tsx << 'EOF'
export default function BillingOverview() {
    const billingData = [
        { month: 'Jan', revenue: 4000, expenses: 2400 },
        { month: 'Feb', revenue: 3000, expenses: 1398 },
        { month: 'Mar', revenue: 9800, expenses: 2000 },
        { month: 'Apr', revenue: 3908, expenses: 2780 },
        { month: 'May', revenue: 4800, expenses: 1890 },
    ];

    return (
        <div className="p-4 bg-white rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Billing Overview</h3>
            <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="text-sm text-gray-500">Current Balance</p>
                        <p className="text-2xl font-bold">$12,450.75</p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-gray-500">Due Date</p>
                        <p className="text-lg font-semibold">May 15, 2024</p>
                    </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                    <div className="p-3 bg-green-50 rounded">
                        <p className="text-sm text-gray-600">Revenue</p>
                        <p className="text-lg font-bold text-green-700">$8,450</p>
                    </div>
                    <div className="p-3 bg-blue-50 rounded">
                        <p className="text-sm text-gray-600">Expenses</p>
                        <p className="text-lg font-bold text-blue-700">$3,240</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded">
                        <p className="text-sm text-gray-600">Profit</p>
                        <p className="text-lg font-bold text-purple-700">$5,210</p>
                    </div>
                </div>
                <div className="pt-4 border-t">
                    <h4 className="text-md font-medium mb-2">Monthly Summary</h4>
                    <div className="space-y-2">
                        {billingData.map((item, index) => (
                            <div key={index} className="flex justify-between">
                                <span className="text-sm">{item.month}</span>
                                <div className="flex space-x-4">
                                    <span className="text-sm text-green-600">+${item.revenue}</span>
                                    <span className="text-sm text-red-600">-${item.expenses}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
EOF

# UserProfile.tsx
cat > components/users/UserProfile.tsx << 'EOF'
export default function UserProfile() {
    const user = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
        role: 'Administrator',
        joinDate: 'January 15, 2023',
        lastLogin: '2 hours ago',
    };

    return (
        <div className="p-6 bg-white rounded-lg shadow">
            <div className="flex items-center space-x-4 mb-6">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center text-2xl">
                    👤
                </div>
                <div>
                    <h2 className="text-2xl font-bold">{user.name}</h2>
                    <p className="text-gray-600">{user.email}</p>
                    <span className="inline-block mt-2 px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded">
                        {user.role}
                    </span>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-500">Join Date</p>
                    <p className="font-medium">{user.joinDate}</p>
                </div>
                <div className="p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-500">Last Login</p>
                    <p className="font-medium">{user.lastLogin}</p>
                </div>
            </div>
            <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">Profile Settings</h3>
                <div className="space-y-3">
                    <button className="w-full text-left p-3 hover:bg-gray-50 rounded border">
                        Edit Profile Information
                    </button>
                    <button className="w-full text-left p-3 hover:bg-gray-50 rounded border">
                        Change Password
                    </button>
                    <button className="w-full text-left p-3 hover:bg-gray-50 rounded border">
                        Notification Settings
                    </button>
                    <button className="w-full text-left p-3 hover:bg-gray-50 rounded border text-red-600">
                        Delete Account
                    </button>
                </div>
            </div>
        </div>
    );
}
EOF

# StatusBadge.tsx
cat > components/StatusBadge.tsx << 'EOF'
interface StatusBadgeProps {
    status: 'active' | 'inactive' | 'pending' | 'success' | 'error';
    text?: string;
}

export default function StatusBadge({ status, text }: StatusBadgeProps) {
    const statusConfig = {
        active: { bg: 'bg-green-100', text: 'text-green-800', defaultText: 'Active' },
        inactive: { bg: 'bg-gray-100', text: 'text-gray-800', defaultText: 'Inactive' },
        pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', defaultText: 'Pending' },
        success: { bg: 'bg-green-100', text: 'text-green-800', defaultText: 'Success' },
        error: { bg: 'bg-red-100', text: 'text-red-800', defaultText: 'Error' },
    };

    const config = statusConfig[status];

    return (
        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.text}`}>
            <span className={`w-2 h-2 rounded-full mr-2 ${config.text.replace('text-', 'bg-')}`}></span>
            {text || config.defaultText}
        </span>
    );
}
EOF

# 3. التحقق من ملف tsconfig.json لمسار @/
if [ -f "tsconfig.json" ]; then
    if ! grep -q '"@/\*"' tsconfig.json; then
        echo "🔧 تحديث paths في tsconfig.json..."
        # نسخ احتياطي
        cp tsconfig.json tsconfig.json.backup
        # إضافة paths
        sed -i '/"compilerOptions": {/a\    "baseUrl": ".",\n    "paths": {\n      "@/*": ["*"]\n    },' tsconfig.json
    fi
else
    echo "📝 إنشاء tsconfig.json جديد..."
    cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "baseUrl": ".",
    "paths": {
      "@/*": ["*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
EOF
fi

# 4. محاولة البناء مرة أخرى
echo "🏗️ محاولة البناء بعد الإصلاح..."
npm run build

echo "✅ تم إنشاء جميع المكونات المفقودة!"