
#!/bin/bash

echo "🧹 بدء تنظيف Git LFS..."

# 1. توقف عن استخدام LFS
git lfs uninstall 2>/dev/null || echo "Git LFS ليس مثبتاً"

# 2. احذف hooks
echo "🗑️  حذف hooks..."
find .git/hooks -name "*lfs*" -delete 2>/dev/null
rm -f .git/hooks/pre-push .git/hooks/pre-commit

# 3. نظف .gitattributes
echo "📝 تنظيف .gitattributes..."
if [ -f ".gitattributes" ]; then
    cp .gitattributes .gitattributes.backup
    grep -v "filter=lfs\|diff=lfs\|merge=lfs\|text=auto" .gitattributes > .gitattributes.tmp
    mv .gitattributes.tmp .gitattributes
    if [ ! -s .gitattributes ]; then
        rm .gitattributes
        echo "🗑️  تم حذف .gitattributes (أصبح فارغاً)"
    fi
fi

# 4. نظف git config
echo "⚙️  تنظيف git config..."
git config --remove-section "lfs" 2>/dev/null
git config --remove-section "filter.lfs" 2>/dev/null
git config --unset core.hookspath 2>/dev/null

# 5. احذف مجلد LFS
echo "🗂️  حذف مجلد .git/lfs..."
rm -rf .git/lfs 2>/dev/null

# 6. أعد تعيين hooks path
echo "🔧 إعادة تعيين hooks..."
git config --global core.hooksPath .git/hooks

echo "✅ تم تنظيف Git LFS بنجاح!"
echo "📌 الآن يمكنك عمل: git add . && git commit -m 'Remove LFS' && git push"

# شغّل السكريبت
chmod +x cleanup-lfs.sh
./cleanup-lfs.sh