#!/bin/bash

set -e

echo "========================================"
echo "🚀 BizAI Development Environment Setup"
echo "========================================"

# 1. تحديث النظام وتثبيت حزم أساسية
echo "📦 تحديث النظام وتثبيت الحزم الأساسية..."
sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt-get install -y \
    build-essential \
    curl \
    wget \
    git \
    gnupg \
    lsb-release \
    ca-certificates \
    software-properties-common \
    python3 \
    python3-pip \
    python3-venv \
    zip \
    unzip

# 2. تثبيت Node.js 20.x (إذا لم يكن مثبتاً مسبقاً)
echo "⬢ تثبيت Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# 3. تثبيت npm وnpm@latest
echo "📦 تثبيت وتحديث npm..."
sudo npm install -g npm@latest
sudo npm install -g yarn
sudo npm install -g pnpm

# 4. التحقق من التثبيت
echo "✅ التحقق من الإصدارات:"
echo "Node: $(node --version)"
echo "npm: $(npm --version)"
echo "Git: $(git --version)"

# 5. تثبيت TurboRepo عالمياً
echo "⚡ تثبيت TurboRepo..."
sudo npm install -g turbo

# 6. إعداد Git
echo "🔧 إعداد Git..."
git config --global --add safe.directory /workspaces/*
git config --global --add safe.directory /workspaces/bizai
git config --global --add safe.directory /workspaces/bizai/*
git config --global user.email "bizai@example.com"
git config --global user.name "BizAI Developer"

# 7. الانتقال إلى مجلد المشروع
cd /workspaces/bizai

# 8. تثبيت اعتماديات المشروع
echo "📁 تثبيت اعتماديات المشروع..."
if [ -f "package.json" ]; then
    # حذف node_modules القديمة
    rm -rf node_modules 2>/dev/null || true
    
    # تثبيت مع خيار --legacy-peer-deps
    npm install --legacy-peer-deps --force
    
    # إذا كان هناك تطبيقات فرعية
    if [ -d "apps" ]; then
        for app in apps/*/; do
            if [ -f "${app}package.json" ]; then
                echo "📦 تثبيت اعتماديات: ${app}"
                cd "${app}"
                rm -rf node_modules 2>/dev/null || true
                npm install --legacy-peer-deps --force || true
                cd /workspaces/bizai
            fi
        done
    fi
fi

# 9. بناء المشروع
echo "🏗️ بناء المشروع..."
if [ -f "package.json" ]; then
    if grep -q '"build"' package.json; then
        npm run build -- --force || echo "⚠️ Build completed with warnings"
    fi
fi

# 10. إعداد الأذونات
echo "🔐 إعداد أذونات المجلدات..."
sudo chown -R $(whoami):$(whoami) /workspaces/bizai
sudo chmod -R 755 /workspaces/bizai

# 11. إنشاء ملفات تعريف للأوامر
echo "📝 إنشاء ملفات تعريف..."
cat > ~/.bash_aliases << 'EOF'
alias ll='ls -la'
alias gs='git status'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline --graph'
alias nr='npm run'
alias ni='npm install'
alias nb='npm run build'
alias nd='npm run dev'
alias nf='npm run format'
alias nt='npm test'
EOF

# تحميل الـ aliases
source ~/.bash_aliases

# 12. إنشاء ملف bashrc مخصص
echo 'source ~/.bash_aliases' >> ~/.bashrc
echo 'export PS1="\[\033[01;32m\]\u@bizai\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ "' >> ~/.bashrc

echo "========================================"
echo "🎉 تم إعداد بيئة التطوير بنجاح!"
echo "✅ Node.js $(node --version)"
echo "✅ npm $(npm --version)"
echo "✅ Git $(git --version)"
echo "✅ Turbo $(turbo --version 2>/dev/null || echo 'installed')"
echo "========================================"
echo "💡 يمكنك البدء بالتطوير الآن!"
echo "👉 استخدم 'npm run dev' لبدء الخوادم"
echo "👉 استخدم 'npm run build' للبناء"
echo "========================================"
