#!/bin/bash

echo "🔧 إصلاح turbo.json لإصدار Turbo 2.0+..."

cd /workspaces/bizai

# 1. إنشاء turbo.json صحيح
echo "📝 إنشاء turbo.json جديد..."

cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "outputs": [".next/**", "!.next/cache/**", "dist/**", "build/**"],
      "dependsOn": ["^build"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "test": {
      "outputs": []
    },
    "lint": {
      "outputs": []
    }
  }
}
EOF

# 2. التحقق من الإصدار
echo "🔍 التحقق من إصدار Turbo..."
npx turbo --version

# 3. تحديث package.json الرئيسي إذا لزم الأمر
echo "📦 تحديث package.json الرئيسي..."

if [ -f "package.json" ]; then
  # إضافة scripts إذا لم تكن موجودة
  if ! grep -q '"build"' package.json; then
    npm pkg set scripts.build="turbo run build"
    npm pkg set scripts.dev="turbo run dev"
    npm pkg set scripts.lint="turbo run lint"
  fi
fi

# 4. تحديث package.json في apps إذا لزم الأمر
for app in apps/*/; do
  if [ -f "${app}package.json" ]; then
    echo "📝 تحديث ${app}package.json"
    cd "${app}"
    
    # إضافة scripts أساسية
    if ! grep -q '"build"' package.json; then
      npm pkg set scripts.build="echo 'Building...'"
    fi
    
    if ! grep -q '"dev"' package.json; then
      npm pkg set scripts.dev="echo 'Dev mode...'"
    fi
    
    cd /workspaces/bizai
  fi
done

# 5. تنظيف cache
echo "🧹 تنظيف cache Turbo..."
rm -rf node_modules/.cache/turbo 2>/dev/null || true

# 6. اختبار Turbo
echo "🧪 اختبار Turbo..."
npx turbo run build --dry=json 2>&1 | head -5

echo ""
echo "✅ تم الإصلاح! تم تغيير 'pipeline' إلى 'tasks'"
echo ""
echo "🎉 جرب الآن: npm run build"