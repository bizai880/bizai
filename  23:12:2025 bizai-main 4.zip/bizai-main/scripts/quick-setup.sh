#!/bin/bash
# scripts/quick-setup.sh - تهيئة سريعة للتطوير اليومي

echo "⚡ البدء السريع لمشروع BizAI..."

# 1. تنظيف cache فقط
turbo clean 2>/dev/null || true
rm -rf /tmp/turbo-cache 2>/dev/null || true
mkdir -p /tmp/turbo-cache
export TURBO_CACHE_DIR="/tmp/turbo-cache"

# 2. تثبيت dependencies الجذرية فقط
npm install --no-audit --no-fund --legacy-peer-deps

# 3. بناء shared package
if [ -f "packages/shared/package.json" ]; then
    cd packages/shared
    npm install --no-audit --no-fund 2>/dev/null || true
    cd ../..
fi

# 4. تشغيل Next.js مع Turbopack
cd apps/web
npm run dev -- --turbopack