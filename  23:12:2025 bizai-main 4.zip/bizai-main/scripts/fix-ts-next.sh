#!/bin/bash
cd /workspaces/bizai

echo "🔧 حل مشاكل typescript و next..."

# 1. تحديث جميع ملفات package.json لإصلاح إصدارات typescript
echo "📦 تحديث إصدارات TypeScript في جميع المشاريع..."

# تحديث package.json الرئيسي
if [ -f "package.json" ]; then
  sed -i 's/"typescript": "5\.3\.0"/"typescript": "^5.0.0"/g' package.json 2>/dev/null || true
fi

# تحديث package.json في جميع apps
for app in apps/*/; do
  if [ -f "${app}package.json" ]; then
    echo "🔄 تحديث ${app}package.json"
    # إصلاح typescript
    sed -i 's/"typescript": "5\.3\.0"/"typescript": "^5.0.0"/g' "${app}package.json" 2>/dev/null || true
    sed -i 's/"typescript": "5\.3\.[0-9]*"/"typescript": "^5.0.0"/g' "${app}package.json" 2>/dev/null || true
    sed -i 's/"typescript": "5\.[0-9]*\.[0-9]*"/"typescript": "^5.0.0"/g' "${app}package.json" 2>/dev/null || true
    
    # إصلاح next في web
    if [[ "$app" == *"web"* ]]; then
      sed -i 's/"next": "15\.[0-9]*\.[0-9]*"/"next": "^15.5.9"/g' "${app}package.json" 2>/dev/null || true
      sed -i 's/"next": ".*"/"next": "^15.5.9"/g' "${app}package.json" 2>/dev/null || true
    fi
  fi
done

# 2. إزالة node_modules وإعادة التثبيت
echo "🧹 تنظيف وإعادة تثبيت..."
rm -rf node_modules apps/*/node_modules 2>/dev/null || true

# 3. تثبيت turbo محلياً أولاً
echo "📥 تثبيت turbo محلياً..."
npm install turbo@^2.6.3 --save-dev --legacy-peer-deps

# 4. تثبيت جميع الاعتماديات
echo "📦 تثبيت الاعتماديات الرئيسية..."
npm install --legacy-peer-deps

# 5. تثبيت اعتماديات كل app بشكل منفصل
echo "📦 تثبيت اعتماديات المشاريع الفرعية..."
for app in apps/*/; do
  if [ -f "${app}package.json" ]; then
    echo "📁 تثبيت ${app}..."
    cd "${app}"
    npm install --legacy-peer-deps 2>/dev/null || echo "⚠️ تخطي ${app}"
    cd /workspaces/bizai
  fi
done

# 6. التحقق من التثبيت
echo "✅ التحقق من التثبيت..."

# تحقق من next
if [ -f "apps/web/node_modules/.bin/next" ]; then
  echo "✅ Next.js مثبت في apps/web"
else
  echo "⚠️ Next.js غير مثبت، جرب التثبيت المباشر..."
  cd apps/web
  npm install next@^15.5.9 react@^18.2.0 react-dom@^18.2.0 --save --legacy-peer-deps
  cd /workspaces/bizai
fi

# تحقق من typescript
if [ -f "node_modules/.bin/tsc" ]; then
  echo "✅ TypeScript مثبت"
else
  echo "⚠️ TypeScript غير مثبت، جرب التثبيت المباشر..."
  npm install typescript@^5.0.0 --save-dev --legacy-peer-deps
fi

echo ""
echo "🎉 تم الإصلاح! جرب الآن:"
echo "   npm run build"