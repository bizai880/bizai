#!/bin/bash

# سكريبت إصلاح مشاكل Turbopack في Next.js
# حفظ كـ: /workspaces/bizai/fix-turbopack.sh
# ثم تشغيل: chmod +x fix-turbopack.sh && ./fix-turbopack.sh

set -e  # يتوقف عند أي خطأ

echo "🚀 بدء إصلاح مشاكل Turbopack..."

# الانتقال لمجلد المشروع
cd /workspaces/bizai/apps/web

# 1. تنظيف الذاكرة المؤقتة
echo "🧹 تنظيف الذاكرة المؤقتة..."
rm -rf .next 2>/dev/null || true
rm -rf node_modules/.cache 2>/dev/null || true
rm -rf .turbo 2>/dev/null || true

# 2. التحقق من ملف next.config.js
echo "🔍 التحقق من next.config.js..."
if [ ! -f "next.config.js" ] && [ ! -f "next.config.mjs" ] && [ ! -f "next.config.ts" ]; then
    echo "📄 إنشاء next.config.js جديد..."
    cat > next.config.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
        turbo: {
            resolveAlias: {
                // إضافة أي aliases مطلوبة هنا
            },
            rules: {
                // قواعد Turbopack الإضافية
            }
        }
    },
    // إعدادات مهمة لـ Turbopack
    typescript: {
        ignoreBuildErrors: false,
    },
    eslint: {
        ignoreDuringBuilds: false,
    },
    webpack: (config, { isServer }) => {
        // تكوين Webpack إضافي إذا لزم
        return config;
    }
}

module.exports = nextConfig
EOF
else
    echo "✅ ملف next.config موجود"
fi

# 3. إصلاح package.json scripts
echo "🔧 تحديث package.json scripts..."
if [ -f "package.json" ]; then
    # حفظ نسخة احتياطية
    cp package.json package.json.backup
    
    # تحديث scripts باستخدام jq (إذا كان مثبتاً)
    if command -v jq &> /dev/null; then
        jq '.scripts.build = "NODE_OPTIONS=\"--max-old-space-size=4096\" next build --turbopack"' package.json > package.json.tmp && mv package.json.tmp package.json
        jq '.scripts.dev = "next dev --turbopack"' package.json > package.json.tmp && mv package.json.tmp package.json
    else
        # بديل بدون jq
        sed -i 's/"build":.*next build.*"/"build": "NODE_OPTIONS=\\"--max-old-space-size=4096\\" next build --turbopack"/g' package.json
        sed -i 's/"dev":.*next dev.*"/"dev": "next dev --turbopack"/g' package.json
    fi
fi

# 4. إنشاء ملف turbo.json إذا لم يكن موجوداً
echo "⚡ إعداد ملف turbo.json..."
if [ ! -f "turbo.json" ]; then
    cat > turbo.json << 'EOF'
{
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
EOF
fi

# 5. إعادة تثبيت الاعتماديات
echo "📦 تحديث الاعتماديات..."
npm ci --no-audit --prefer-offline || npm install --no-audit

# 6. التحقق من إصدارات الأدوات
echo "📊 التحقق من الإصدارات..."
echo "Node.js: $(node --version)"
echo "npm: $(npm --version)"
npx next --version || echo "Next.js غير مثبت"

# 7. تشغيل بناء مع سجل تفصيلي
echo "🔨 تشغيل بناء تجريبي مع سجل تفصيلي..."
NODE_OPTIONS="--max-old-space-size=4096" npx next build --turbopack --verbose 2>&1 | tee build.log || {
    echo "⚠️  هناك أخطاء في البناء، راجع build.log"
    echo "🔄 تجربة حلول بديلة..."
}

# 8. التحقق من وجود أخطاء شائعة
echo "🔎 البحث عن أخطاء معروفة..."
if grep -q "Call retries were exceeded" build.log 2>/dev/null; then
    echo "🎯 تم اكتشاف خطأ 'Call retries were exceeded'"
    echo "💡 الحل: زيادة المهلة وتحسين الذاكرة"
    
    # تحديث next.config.js لإضافة إعدادات Turbopack محسنة
    cat >> next.config.js << 'EOF'

// إعدادات Turbopack محسنة
if (process.env.TURBOPACK) {
    console.log('🚀 Turbopack mode enabled');
    nextConfig.experimental = {
        ...nextConfig.experimental,
        turbo: {
            ...nextConfig.experimental?.turbo,
            maxWorkers: require('os').cpus().length,
            memoryLimit: 4096,
            resolveExtensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
        }
    };
}
EOF
fi

# 9. إنشاء ملف env للتطوير
echo "🌐 إعداد متغيرات البيئة..."
if [ ! -f ".env.local" ]; then
    cat > .env.local << 'EOF'
# إعدادات Turbopack
TURBOPACK=true
NEXT_TELEMETRY_DISABLED=1

# إعدادات الذاكرة
NODE_OPTIONS=--max-old-space-size=4096

# إعدادات التطوير
NEXT_PUBLIC_APP_ENV=development
EOF
fi

# 10. إنشاء سكريبت dev محسن
echo "📝 إنشاء سكريبت بدء محسن..."
cat > start-dev.sh << 'EOF'
#!/bin/bash
# سكريبت بدء التطوير مع Turbopack
cd /workspaces/bizai/apps/web
export NODE_OPTIONS="--max-old-space-size=4096"
export TURBOPACK=1

echo "🚀 بدء Next.js مع Turbopack..."
echo "📊 الذاكرة: $NODE_OPTIONS"
echo "⚡ Turbopack: مفعل"

# تشغيل next dev مع مراقبة الذاكرة
exec npx next dev --turbopack --port=3000 --hostname=0.0.0.0
EOF

chmod +x start-dev.sh

# 11. إنشاء سكريبت build محسن
echo "📝 إنشاء سكريبت بناء محسن..."
cat > build-prod.sh << 'EOF'
#!/bin/bash
# سكريبت البناء النهائي مع Turbopack
cd /workspaces/bizai/apps/web
export NODE_OPTIONS="--max-old-space-size=8192"
export TURBOPACK=1

echo "🏗️  بدء البناء مع Turbopack..."
echo "📊 الذاكرة: $NODE_OPTIONS"
echo "⚡ Turbopack: مفعل"

# تنظيف الذاكرة المؤقتة
rm -rf .next 2>/dev/null || true
rm -rf node_modules/.cache 2>/dev/null || true

# بناء مع سجل تفصيلي
exec npx next build --turbopack 2>&1 | tee build-output.log
EOF

chmod +x build-prod.sh

echo "✅ تم الانتهاء من الإصلاح!"
echo ""
echo "📋 الخطوات التالية:"
echo "1. 🔧 تحقق من ملف next.config.js"
echo "2. 🚀 ابدأ التطوير: ./start-dev.sh"
echo "3. 🏗️  للبناء: ./build-prod.sh"
echo "4. 📄 للتفاصيل: راجع build.log"
echo ""
echo "💡 نصائح إضافية:"
echo "- تأكد من أن جميع الاعتماديات متوافقة مع Turbopack"
echo"- تحقق من عدم وجود حلقات في imports"
echo "- تأكد من صحة جميع ملفات TypeScript"