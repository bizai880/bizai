```bash
#!/bin/bash

echo "📝 إنشاء دليل النشر الشامل DEPLOYMENT_GUIDE.md..."

cd /workspaces/bizai

cat > DEPLOYMENT_GUIDE.md << 'GUIDE'
# 📘 دليل النشر الشامل - مشروع BizAI

## 🎯 نظرة عامة

مشروع **BizAI** هو تطبيق Next.js 15 متكامل يعمل على **Turbo Monorepo**، يحتوي على:
- **apps/web**: تطبيق Next.js 15 الرئيسي
- **apps/ai-worker**: worker معالجة AI

## ✅ الحالة الحالية

تم إكمال جميع الإعدادات بنجاح:
- ✅ البناء المحلي يعمل مع **FULL TURBO**
- ✅ إصلاح مشاكل Next.js 15 و `swcMinify`
- ✅ إعدادات Vercel كاملة
- ✅ رفع الكود إلى GitHub

## 🚀 خطوات النشر على Vercel

### 1. الملفات المضافة للنشر

```

/workspaces/bizai/
├── vercel.json              # إعدادات Vercel
├── .vercelignore            # تجاهل الملفات غير الضرورية
├── apps/web/public/         # ملفات static
└── DEPLOYMENT_GUIDE.md      # هذا الدليل

```

### 2. إعدادات Vercel المطلوبة

#### في Vercel Dashboard → Project Settings:

##### أ) Environment Variables (ضرورية):

```env
# إعدادات البيئة الأساسية
NODE_ENV=production

# إعدادات المصادقة والأمان
JWT_SECRET=your_jwt_secret_here
ENCRYPTION_KEY=your_encryption_key_here

# إعدادات Supabase
SUPABASE_JWT_SECRET=your_supabase_jwt_secret
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# إعدادات Redis
REDIS_URL=your_redis_url
REDIS_PASSWORD=your_redis_password
UPSTASH_REDIS_URL=your_upstash_redis_url
UPSTASH_REDIS_TOKEN=your_upstash_redis_token

# إعدادات Inngest
INNGEST_SIGNING_KEY=your_inngest_signing_key
INNGEST_EVENT_KEY=your_inngest_event_key

# إعدادات APIs
SLACK_TOKEN=your_slack_token
GROQ_API_KEY=your_groq_api_key
```

ب) Build Settings:

الإعداد القيمة
Build Command cd apps/web && npm run build
Output Directory apps/web/.next
Install Command npm install
Framework Preset Next.js

ج) Domains:

· رابط Vercel الافتراضي: https://[project-name].vercel.app
· لإضافة domain مخصص: Settings → Domains

3. مراحل البناء في Vercel

```
1. ⬇️  Clone المشروع من GitHub
2. 📦 تثبيت dependencies (npm install)
3. 🔨 بناء المشروع (cd apps/web && npm run build)
4. 🚀 نشر الملفات المضغوطة
5. 🌐 الموقع متاح على الإنترنت
```

🔧 استكشاف الأخطاء وإصلاحها

إذا فشل البناء في Vercel:

1. تحقق من Logs:

```bash
# في Vercel Dashboard → Deployments → [Latest Deployment] → Logs
```

2. الأخطاء الشائعة وحلولها:

أ) خطأ: Module not found

```bash
# حل محلي:
cd /workspaces/bizai
rm -rf node_modules apps/*/node_modules
npm install
cd apps/web && npm install
```

ب) خطأ: Environment variables missing

· تأكد من إضافة جميع Environment Variables في Vercel Dashboard

ج) خطأ: Build timeout

· في vercel.json:

```json
{
  "functions": {
    "apps/web/.next/**/*.js": {
      "maxDuration": 60
    }
  }
}
```

3. اختبار البناء محلياً:

```bash
# اختبار بناء Vercel محاكاة
cd apps/web
npm run build

# أو من الجذر
npx turbo run build
```

⚡ أوامر التطوير المحلي

البناء والتطوير:

```bash
# البناء الكامل
npm run build

# وضع التطوير
npm run dev

# تنظيف المشروع
npm run clean:all

# اختبار البناء لـ Vercel
npm run vercel-build
```

إدارة الحزم:

```bash
# تثبيت dependencies من الجذر
npm install

# تثبيت في apps/web
cd apps/web && npm install

# تحديث Next.js
cd apps/web && npm install next@latest
```

📊 بنية المشروع

```
bizai/
├── apps/
│   ├── web/                    # تطبيق Next.js الرئيسي
│   │   ├── app/               # App Router (Next.js 15)
│   │   ├── components/        # مكونات React
│   │   ├── lib/              # مكتبات مساعدة
│   │   ├── public/           # ملفات static
│   │   └── next.config.js    # إعدادات Next.js
│   └── ai-worker/            # معالجة AI الخلفية
├── packages/                  # حزم مشتركة
├── turbo.json                # إعدادات Turbo
├── vercel.json              # إعدادات Vercel
└── package.json             # إعدادات المشروع الرئيسي
```

🔐 الأمان

1. Environment Variables:

· لا ترفع ملفات .env إلى GitHub
· استخدم Vercel Environment Variables
· استخدم Git-crypt إذا لزم

2. ملفات حساسة:

```
# يجب تجاهلها في .gitignore
.env*
*.pem
*.key
config/*.secret
```

3. Headers الأمان (مضمنة في next.config.js):

```javascript
headers: [
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  },
  {
    key: 'X-Frame-Options',
    value: 'DENY'
  }
]
```

📈 المراقبة والتحليلات

1. Vercel Analytics:

· Vercel Dashboard → Analytics
· تتبع الأداء والاستخدام

2. Health Checks:

```bash
# تحقق من صحة التطبيق
curl https://[your-domain]/api/health

# تحقق من صحة worker
curl https://[your-domain]/api/worker-health
```

3. Logs:

· Vercel Dashboard → Logs
· Real-time logs أثناء التطوير

🔄 التحديثات والصيانة

تحديث Next.js:

```bash
cd apps/web
npm install next@latest react@latest react-dom@latest
```

تحديث Turbo:

```bash
npm install turbo@latest --save-dev
```

تنظيف Cache:

```bash
# تنظيف Turbo cache
npx turbo run clean

# تنظيف npm cache
npm cache clean --force

# حذف node_modules وإعادة التثبيت
rm -rf node_modules apps/*/node_modules
npm install
```

📞 الدعم والمراجع

وثائق مهمة:

· Next.js 15 Documentation
· Vercel Deployment Guide
· Turbo Repo Documentation

استكشاف الأخطاء:

1. تحقق من Vercel Logs أولاً
2. اختبر البناء محلياً
3. تأكد من Environment Variables
4. تحقق من إصدارات الحزم

للطوارئ:

```bash
# إعادة تعيين كاملة
git clean -fdx
git reset --hard
npm install
npm run build
```

🎉 النشر الناجح

بعد النشر الناجح، سترى:

✅ Vercel Deployment: https://[project].vercel.app
✅ GitHub Integration: تحديث تلقائي عند push
✅ SSL/TLS: مجاني وتلقائي
✅ CDN: توزيع عالمي
✅ Auto-scaling: حسب الطلب

---

تم إعداد المشروع بالكامل وجاهز للإنتاج! 🚀

آخر تحديث: $(date +"%Y-%m-%d %H:%M:%S")
GUIDE

echo "✅ تم إنشاء DEPLOYMENT_GUIDE.md"
echo ""
echo "📖 محتويات الدليل:"
echo "================="
echo "1. 🎯 نظرة عامة عن المشروع"
echo "2. 🚀 خطوات النشر على Vercel"
echo "3. 🔧 استكشاف الأخطاء"
echo "4. ⚡ أوامر التطوير"
echo "5. 📊 بنية المشروع"
echo "6. 🔐 إرشادات الأمان"
echo "7. 📈 المراقبة والتحليلات"
echo "8. 🔄 التحديثات والصيانة"
echo "9. 📞 الدعم والمراجع"
echo ""
echo "لإضافة الدليل إلى Git:"
echo "git add DEPLOYMENT_GUIDE.md"
echo "git commit -m 'docs: إضافة دليل النشر الشامل'"
echo "git push"

```

## **لرفع الدليل إلى GitHub:**

```bash
git add DEPLOYMENT_GUIDE.md
git commit -m "docs: إضافة دليل النشر الشامل DEPLOYMENT_GUIDE.md"
git push origin main
```

الدليل النهائي يحتوي على:

1. كل المعلومات اللازمة للنشر والصيانة
2. خطوات استكشاف الأخطاء
3. أوامر التطوير الأساسية
4. إرشادات الأمان
5. روابط الوثائق المهمة

الآن فريقك لديه مرجع شامل لكل ما يحتاجونه للنشر والصيانة! 📘