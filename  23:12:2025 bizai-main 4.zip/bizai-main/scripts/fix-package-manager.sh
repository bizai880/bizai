#!/bin/bash

echo "🔧 إصلاح إعدادات Turbo والـ package.json..."

cd /workspaces/bizai

# 1. تحديث package.json الأساسي
echo "📦 تحديث package.json الرئيسي..."
cat > package.json << 'EOF'
{
  "name": "bizai-factory",
  "version": "1.0.0",
  "private": true,
  "packageManager": "npm@10.2.4",
  "workspaces": ["apps/*"],
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "lint": "turbo run lint",
    "test": "turbo run test",
    "clean": "turbo run clean",
    "clean:all": "rm -rf node_modules apps/*/node_modules .turbo",
    "docker:build": "turbo run docker:build"
  },
  "devDependencies": {
    "turbo": "^2.6.3"
  },
  "engines": {
    "node": ">=18.0.0",
    "npm": ">=10.0.0"
  }
}
EOF

# 2. تحديث turbo.json مع إعدادات كاملة
echo "📝 تحديث turbo.json..."
cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "globalEnv": ["CI", "NODE_ENV"],
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "inputs": ["src/**/*", "public/**/*", "package.json", "tsconfig.json", "next.config.*", "tailwind.config.*"],
      "outputs": ["dist/**", ".next/**", "!.next/cache/**"],
      "cache": true
    },
    "dev": {
      "cache": false,
      "persistent": true,
      "interruptible": true
    },
    "lint": {
      "outputs": [],
      "cache": true
    },
    "test": {
      "outputs": [],
      "cache": true
    },
    "clean": {
      "cache": false
    }
  }
}
EOF

# 3. تحديث package.json في web
echo "🔧 تحديث apps/web/package.json..."
cd apps/web

if [ -f "package.json" ]; then
  # إنشاء نسخة احتياطية
  cp package.json package.json.backup
  
  # تحديث package.json مع packageManager
  cat > package.json << 'EOF'
{
  "name": "bizai-web",
  "version": "1.0.0",
  "private": true,
  "packageManager": "npm@10.2.4",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "clean": "rm -rf .next"
  },
  "dependencies": {
    "next": "15.0.0",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "tailwindcss": "^3.4.0",
    "@types/node": "20.10.0",
    "@types/react": "18.2.0",
    "@types/react-dom": "18.2.0",
    "typescript": "5.3.0"
  },
  "devDependencies": {
    "@tailwindcss/typography": "^0.5.10",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32"
  }
}
EOF
fi

# 4. تحديث package.json في ai-worker
echo "🔧 تحديث apps/ai-worker/package.json..."
cd ../ai-worker

if [ -f "package.json" ]; then
  cat > package.json << 'EOF'
{
  "name": "bizai-ai-worker",
  "version": "1.0.0",
  "packageManager": "npm@10.2.4",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc --skipLibCheck",
    "dev": "tsc --watch",
    "start": "node dist/index.js",
    "clean": "rm -rf dist"
  },
  "dependencies": {
    "express": "^4.18.2"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^20.10.0",
    "typescript": "^5.3.0"
  }
}
EOF
fi

# 5. الرجوع للمجلد الرئيسي وإنشاء ملفات إضافية
cd /workspaces/bizai

# 6. إنشاء ملف .npmrc لتكوين npm
echo "⚙️ إنشاء .npmrc..."
cat > .npmrc << 'EOF'
engine-strict=true
strict-peer-dependencies=false
legacy-peer-deps=true
save-exact=true
EOF

# 7. إنشاء ملف .nvmrc لتحديد إصدار Node.js
echo "⬢ إنشاء .nvmrc..."
echo "20.10.0" > .nvmrc

# 8. التحقق من تثبيت Turbo
echo "📥 التحقق من تثبيت Turbo..."
npm list turbo 2>/dev/null || npm install turbo@latest --save-dev

# 9. تنظيف وإعادة التثبيت
echo "🧹 تنظيف وإعادة التثبيت..."
rm -rf node_modules apps/*/node_modules .turbo 2>/dev/null || true
npm install --legacy-peer-deps

# 10. اختبار Turbo
echo "🧪 اختبار Turbo..."
npx turbo --version
npx turbo run build --dry 2>&1 | head -10

echo ""
echo "✅ تم الإصلاح! جرب الآن:"
echo "   npm run build"