#!/bin/bash

echo "🔧 إصلاح أخطاء بناء TurboRepo..."

# الانتقال إلى المجلد الرئيسي
cd /workspaces/bizai

# 1. تنظيف node_modules والملفات المبنية
echo "🧹 تنظيف node_modules و cache..."
rm -rf node_modules
rm -rf apps/ai-worker/node_modules
rm -rf apps/web/node_modules
rm -rf apps/ai-worker/dist
rm -rf apps/web/.next

# 2. إعادة تثبيت الاعتماديات
echo "📦 إعادة تثبيت الاعتماديات..."
npm install

# 3. التحقق من ملفات TypeScript
echo "🔍 التحقق من ملفات TypeScript في ai-worker..."
cd apps/ai-worker

# إصلاح أخطاء TypeScript إذا وجدت
if [ -f "src/health.ts" ]; then
    echo "📝 فحص src/health.ts..."
    npx tsc --noEmit src/health.ts || {
        echo "🛠️ محاولة إصلاح health.ts..."
        # يمكن إضافة إصلاحات محددة هنا
        cp src/health.ts src/health.ts.backup
    }
fi

if [ -f "src/index.ts" ]; then
    echo "📝 فحص src/index.ts..."
    npx tsc --noEmit src/index.ts || {
        echo "🛠️ محاولة إصلاح index.ts..."
        cp src/index.ts src/index.ts.backup
    }
fi

# 4. محاولة البناء بشكل منفصل
echo "🏗️ محاولة بناء ai-worker بشكل منفصل..."
cd /workspaces/bizai/apps/ai-worker
npm run build || {
    echo "⚠️ فشل البناء الأول، تجربة مع خيارات مختلفة..."
    npx tsc --skipLibCheck || npx tsc --noEmit
}

# 5. إصلاح مشاكل web
echo "🌐 إصلاح مشاكل web..."
cd /workspaces/bizai/apps/web
rm -rf .next
npm run build || {
    echo "⚠️ فشل بناء web، تجربة مع Next.js في وضع development..."
    NEXT_PUBLIC_DISABLE_STRICT_MODE=true npm run build || {
        echo "🔧 تجربة تثبيت اعتماديات إضافية..."
        npm install next react react-dom @types/react @types/react-dom --save
    }
}

# 6. تجربة البناء مع Turbo
echo "🚀 تجربة البناء مع TurboRepo..."
cd /workspaces/bizai
npm run build -- --force || {
    echo "🔄 تجربة بدون cache..."
    npm run build -- --no-cache --force
}

echo "✅ تم الانتهاء من محاولات الإصلاح!"