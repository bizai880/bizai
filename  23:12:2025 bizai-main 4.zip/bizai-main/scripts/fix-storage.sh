#!/bin/bash

echo "🔧 إصلاح مكتبة storage المفقودة في web..."

cd /workspaces/bizai/apps/web

# 1. إنشاء مجلدات storage
echo "📁 إنشاء مجلدات ومكتبات storage..."
mkdir -p lib/storage

# 2. إنشاء مكتبة uploader
cat > lib/storage/uploader.ts << 'EOF'
/**
 * Storage Uploader Module
 * Handles file uploads to various storage providers
 */

export interface UploadOptions {
  maxFileSize?: number;
  allowedMimeTypes?: string[];
  public?: boolean;
  metadata?: Record<string, any>;
}

export interface UploadResult {
  success: boolean;
  url?: string;
  key?: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  uploadedAt: string;
  error?: string;
}

export interface FileInfo {
  name: string;
  size: number;
  type: string;
  lastModified: number;
}

export class StorageUploader {
  private config: {
    maxFileSize: number;
    allowedTypes: string[];
    defaultBucket: string;
  };

  constructor(config?: Partial<typeof this.config>) {
    this.config = {
      maxFileSize: 10 * 1024 * 1024, // 10MB
      allowedTypes: ['image/*', 'application/pdf', 'text/plain'],
      defaultBucket: 'uploads',
      ...config
    };
  }

  /**
   * Validate file before upload
   */
  validateFile(file: File | FileInfo, options?: UploadOptions): { valid: boolean; error?: string } {
    const maxSize = options?.maxFileSize || this.config.maxFileSize;
    const allowedTypes = options?.allowedMimeTypes || this.config.allowedTypes;

    // Check file size
    if (file.size > maxSize) {
      return {
        valid: false,
        error: `File size ${this.formatBytes(file.size)} exceeds maximum allowed size ${this.formatBytes(maxSize)}`
      };
    }

    // Check file type
    const isTypeAllowed = allowedTypes.some(allowedType => {
      if (allowedType.endsWith('/*')) {
        const category = allowedType.split('/')[0];
        return file.type.startsWith(`${category}/`);
      }
      return file.type === allowedType;
    });

    if (!isTypeAllowed) {
      return {
        valid: false,
        error: `File type ${file.type} is not allowed. Allowed types: ${allowedTypes.join(', ')}`
      };
    }

    return { valid: true };
  }

  /**
   * Upload file to storage
   */
  async uploadFile(
    file: File | Buffer | string,
    fileName: string,
    options?: UploadOptions
  ): Promise<UploadResult> {
    const startTime = Date.now();
    
    try {
      // Prepare file info
      const fileInfo: FileInfo = {
        name: fileName,
        size: file instanceof File ? file.size : Buffer.isBuffer(file) ? file.length : file.length,
        type: file instanceof File ? file.type : 'application/octet-stream',
        lastModified: Date.now()
      };

      // Validate file
      const validation = this.validateFile(fileInfo, options);
      if (!validation.valid) {
        throw new Error(validation.error);
      }

      // Simulate upload (replace with actual storage service)
      await this.simulateUpload(fileInfo);

      // Generate URL (mock implementation)
      const fileKey = `uploads/${Date.now()}-${fileName.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
      const fileUrl = `/storage/${fileKey}`;

      const result: UploadResult = {
        success: true,
        url: fileUrl,
        key: fileKey,
        fileName: fileInfo.name,
        fileSize: fileInfo.size,
        mimeType: fileInfo.type,
        uploadedAt: new Date().toISOString()
      };

      console.log(`✅ File uploaded: ${fileName} (${this.formatBytes(fileInfo.size)})`);
      return result;

    } catch (error) {
      console.error('❌ Upload failed:', error);
      
      return {
        success: false,
        fileName,
        fileSize: 0,
        mimeType: 'unknown',
        uploadedAt: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Upload failed'
      };
    }
  }

  /**
   * Upload multiple files
   */
  async uploadFiles(
    files: Array<{ file: File | Buffer | string; fileName: string }>,
    options?: UploadOptions
  ): Promise<UploadResult[]> {
    const uploadPromises = files.map(({ file, fileName }) =>
      this.uploadFile(file, fileName, options)
    );
    
    return Promise.all(uploadPromises);
  }

  /**
   * Delete file from storage
   */
  async deleteFile(fileKey: string): Promise<{ success: boolean; error?: string }> {
    try {
      // Simulate deletion
      await new Promise(resolve => setTimeout(resolve, 100));
      console.log(`🗑️ File deleted: ${fileKey}`);
      
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Delete failed'
      };
    }
  }

  /**
   * Get file info
   */
  async getFileInfo(fileKey: string): Promise<FileInfo | null> {
    // Mock implementation
    return {
      name: fileKey.split('/').pop() || 'unknown',
      size: 1024,
      type: 'application/octet-stream',
      lastModified: Date.now() - 3600000
    };
  }

  /**
   * Generate presigned URL for upload
   */
  async generatePresignedUrl(
    fileName: string,
    options?: { expiresIn?: number; contentType?: string }
  ): Promise<{ url: string; fields?: Record<string, string> }> {
    const expiresIn = options?.expiresIn || 3600;
    const url = `/api/upload/signed?file=${encodeURIComponent(fileName)}&expires=${expiresIn}`;
    
    return {
      url,
      fields: {
        'Content-Type': options?.contentType || 'application/octet-stream',
        'x-amz-meta-filename': fileName
      }
    };
  }

  /**
   * Format bytes to human readable
   */
  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Simulate upload (for testing)
   */
  private async simulateUpload(fileInfo: FileInfo): Promise<void> {
    // Simulate upload delay based on file size
    const delay = Math.min(100 + (fileInfo.size / 1024), 2000);
    await new Promise(resolve => setTimeout(resolve, delay));
  }
}

// Export singleton instance
export const storageUploader = new StorageUploader();

// Export individual functions for convenience
export const uploadFile = storageUploader.uploadFile.bind(storageUploader);
export const uploadFiles = storageUploader.uploadFiles.bind(storageUploader);
export const deleteFile = storageUploader.deleteFile.bind(storageUploader);
export const generatePresignedUrl = storageUploader.generatePresignedUrl.bind(storageUploader);
export const validateFile = storageUploader.validateFile.bind(storageUploader);

// Default export
export default storageUploader;
EOF

# 3. إنشاء ملف index للـ storage
cat > lib/storage/index.ts << 'EOF'
export { storageUploader, uploadFile, uploadFiles, deleteFile, generatePresignedUrl, validateFile } from './uploader';
export type { UploadOptions, UploadResult, FileInfo } from './uploader';

// Export default
import storageUploader from './uploader';
export default storageUploader;
EOF

# 4. إصلاح مكتبة inngest لتستخدم storage بشكل صحيح
echo "🔧 تحديث مكتبة inngest..."

# إنشاء مجلد functions إذا لم يكن موجوداً
mkdir -p lib/inngest/functions

# تحديث ملف generate-excel
if [ -f "lib/inngest/functions/generate-excel.ts" ]; then
    sed -i "s|import.*@/lib/storage/uploader.*|import { storageUploader } from '../storage/uploader';|g" lib/inngest/functions/generate-excel.ts
else
    cat > lib/inngest/functions/generate-excel.ts << 'EOF'
import { storageUploader } from '../storage/uploader';

export interface ExcelData {
  headers: string[];
  rows: any[][];
  title?: string;
}

export async function generateExcel(data: ExcelData): Promise<string> {
  try {
    console.log('Generating Excel file...');
    
    // Simulate Excel generation
    const csvContent = [
      data.headers.join(','),
      ...data.rows.map(row => row.join(','))
    ].join('\n');
    
    const fileName = `report-${Date.now()}.csv`;
    const uploadResult = await storageUploader.uploadFile(
      Buffer.from(csvContent, 'utf-8'),
      fileName,
      {
        allowedMimeTypes: ['text/csv'],
        metadata: {
          title: data.title || 'Generated Report',
          rowCount: data.rows.length,
          generatedAt: new Date().toISOString()
        }
      }
    );
    
    if (!uploadResult.success) {
      throw new Error(uploadResult.error || 'Failed to upload Excel file');
    }
    
    return uploadResult.url || `/downloads/${fileName}`;
  } catch (error) {
    console.error('Excel generation failed:', error);
    throw error;
  }
}

export default generateExcel;
EOF
fi

# 5. التحقق من ملف inngest الرئيسي
if [ -f "lib/inngest/inngest.ts" ]; then
    # إضافة استيراد storage إذا لم يكن موجوداً
    if ! grep -q "storageUploader" lib/inngest/inngest.ts; then
        sed -i "/import.*/a import { storageUploader } from './storage/uploader';" lib/inngest/inngest.ts
    fi
else
    # إنشاء ملف inngest إذا لم يكن موجوداً
    cat > lib/inngest/inngest.ts << 'EOF'
import { Inngest } from 'inngest';
import { storageUploader } from './storage/uploader';
import { generateExcel } from './functions/generate-excel';

// Create Inngest client
export const inngest = new Inngest({
  id: 'bizai-web',
  name: 'BizAI Web Application'
});

// Define functions
export const functions = {
  processUpload: inngest.createFunction(
    { id: 'process-upload', name: 'Process File Upload' },
    { event: 'file.uploaded' },
    async ({ event, step }) => {
      const { fileUrl, userId, fileName } = event.data;
      
      // Download and process file
      const fileData = await step.run('download-file', async () => {
        console.log(`Downloading file: ${fileName}`);
        return { content: 'mock file content' };
      });
      
      // Store in storage
      const uploadResult = await step.run('store-file', async () => {
        return await storageUploader.uploadFile(
          fileData.content,
          `processed-${fileName}`,
          { metadata: { processed: true, userId } }
        );
      });
      
      return { success: true, storedUrl: uploadResult.url };
    }
  ),
  
  generateReport: inngest.createFunction(
    { id: 'generate-report', name: 'Generate Excel Report' },
    { event: 'report.requested' },
    async ({ event, step }) => {
      const { data, reportType, userId } = event.data;
      
      const excelData = await step.run('prepare-data', async () => {
        return {
          headers: ['Date', 'Metric', 'Value'],
          rows: data.map((item: any) => [item.date, item.metric, item.value]),
          title: `${reportType} Report`
        };
      });
      
      const excelUrl = await step.run('generate-excel', async () => {
        return await generateExcel(excelData);
      });
      
      return { reportGenerated: true, url: excelUrl };
    }
  )
};

export default inngest;
EOF
fi

# 6. تحديث tsconfig.json لإضافة paths
echo "⚙️ تحديث tsconfig.json..."

if [ -f "tsconfig.json" ]; then
    # إضافة path لـ @/lib/storage
    if ! grep -q '"@/lib/storage"' tsconfig.json; then
        sed -i '/"paths": {/a\      "@/lib/storage/*": ["lib/storage/*"],' tsconfig.json
    fi
else
    cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"],
      "@/lib/*": ["lib/*"],
      "@/lib/storage/*": ["lib/storage/*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
EOF
fi

# 7. إنشاء ملف API route إذا لم يكن موجوداً
mkdir -p app/api/upload

cat > app/api/upload/route.ts << 'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { storageUploader } from '@/lib/storage/uploader';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json(
        { success: false, error: 'No file provided' },
        { status: 400 }
      );
    }
    
    const uploadResult = await storageUploader.uploadFile(
      file,
      file.name,
      {
        maxFileSize: 50 * 1024 * 1024, // 50MB
        allowedMimeTypes: [
          'image/*',
          'application/pdf',
          'text/plain',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ]
      }
    );
    
    return NextResponse.json(uploadResult);
    
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Upload failed'
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  return NextResponse.json({
    endpoint: 'file-upload',
    maxFileSize: '50MB',
    allowedTypes: ['images', 'pdf', 'text', 'excel'],
    methods: ['POST']
  });
}
EOF

# 8. محاولة البناء
echo "🏗️ محاولة بناء web..."
npm run build 2>&1 | grep -A10 -B5 "error" || {
    echo "✅ البناء نجح!"
    echo ""
    echo "📁 الملفات التي تم إنشاؤها:"
    find lib/storage -name "*.ts" -type f
    echo ""
    echo "🚀 يمكنك الآن استخدام:"
    echo "   import { storageUploader } from '@/lib/storage/uploader'"
    echo "   أو"
    echo "   import storageUploader from '@/lib/storage'"
}

echo "🎉 تم إنشاء مكتبة storage وإصلاح مشكلة الاستيراد!"