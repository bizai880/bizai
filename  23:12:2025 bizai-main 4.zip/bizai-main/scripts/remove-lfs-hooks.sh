#!/bin/bash
echo "🚫 إزالة Git LFS hooks نهائياً..."

# 1. إيقاف Git LFS
echo "⏹️  إيقاف Git LFS..."
git lfs uninstall 2>/dev/null || echo "⚠️  Git LFS غير مثبت أو تم إيقافه مسبقاً"

# 2. تنظيف جميع hooks
echo "🧹 تنظيف hooks..."
HOOKS_DIR=".git/hooks"
if [ -d "$HOOKS_DIR" ]; then
    echo "📁 حذف جميع الملفات في $HOOKS_DIR..."
    rm -f "$HOOKS_DIR"/pre-commit "$HOOKS_DIR"/pre-push "$HOOKS_DIR"/post-commit "$HOOKS_DIR"/post-checkout "$HOOKS_DIR"/post-merge
    
    # حذف أي ملف يحتوي على lfs
    find "$HOOKS_DIR" -name "*lfs*" -delete 2>/dev/null
    echo "✅ تم حذف hooks"
else
    echo "📁 إنشاء مجلد hooks..."
    mkdir -p "$HOOKS_DIR"
fi

# 3. تنظيف git config من إعدادات LFS
echo "⚙️  تنظيف git config..."
git config --remove-section lfs 2>/dev/null
git config --remove-section filter.lfs 2>/dev/null

# 4. إعادة تعيين hookspath
echo "🔧 إعادة تعيين hookspath..."
git config --unset-all core.hookspath 2>/dev/null
git config --global --unset-all core.hookspath 2>/dev/null
git config --global core.hooksPath .git/hooks

# 5. تنظيف .gitattributes من إشارات LFS
echo "📝 تنظيف .gitattributes..."
if [ -f ".gitattributes" ]; then
    cp .gitattributes .gitattributes.backup
    grep -v "filter=lfs\|diff=lfs\|merge=lfs\|text=auto" .gitattributes > .gitattributes.tmp
    mv .gitattributes.tmp .gitattributes
    echo "✅ تم تنظيف .gitattributes (النسخة الاحتياطية: .gitattributes.backup)"
fi

# 6. إنشاء hooks فارغة جديدة
echo "🆕 إنشاء hooks فارغة جديدة..."
cat > .git/hooks/pre-push << 'HOOK_PRE_PUSH'
#!/bin/bash
# Git Hook فارغ لمنع تحذيرات Git LFS
# تم إنشاؤه بواسطة remove-lfs-hooks.sh
exit 0
HOOK_PRE_PUSH

cat > .git/hooks/pre-commit << 'HOOK_PRE_COMMIT'
#!/bin/bash
# Git Hook فارغ
exit 0
HOOK_PRE_COMMIT

cat > .git/hooks/post-commit << 'HOOK_POST_COMMIT'
#!/bin/bash
# Git Hook فارغ
exit 0
HOOK_POST_COMMIT

# جعلها قابلة للتنفيذ
chmod +x .git/hooks/pre-push .git/hooks/pre-commit .git/hooks/post-commit

# 7. حذف مجلد .git/lfs إذا كان موجوداً
echo "🗑️  حذف مجلد .git/lfs..."
rm -rf .git/lfs 2>/dev/null && echo "✅ تم حذف .git/lfs" || echo "⚠️  مجلد .git/lfs غير موجود"

# 8. التحقق من الإصلاح
echo "🔍 التحقق من الإصلاح..."
echo "📊 حالة hooks:"
ls -la .git/hooks/ 2>/dev/null | grep -E "pre-|post-" || echo "⚠️  لا توجد hooks"

echo "📊 إعدادات git config المتعلقة بـLFS:"
git config --list | grep -i "lfs\|hook" || echo "✅ لا توجد إشارات LFS أو hooks"

# 9. جرب push
echo "📤 محاولة push..."
echo "🚀 تشغيل: git push origin main --no-verify"
git push origin main --no-verify

if [ $? -eq 0 ]; then
    echo "🎉 تم push بنجاح!"
else
    echo "⚠️  Push فشل، جرب البديل:"
    echo "git push origin main --no-verify --force-with-lease"
fi

echo "✅ تم الانتهاء من إزالة Git LFS hooks!"