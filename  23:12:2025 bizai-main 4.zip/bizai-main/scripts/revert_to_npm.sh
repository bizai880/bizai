#!/bin/bash
cd /workspaces/bizai

echo "🔧 التراجع عن التغييرات والرجوع إلى npm..."

# 1. إزالة pnpm (اختياري)
npm uninstall -g pnpm 2>/dev/null || true

# 2. حذف إعدادات pnpm المسببة للمشكلة
rm -f pnpm-workspace.yaml pnpm-workspaces.yaml 2>/dev/null || true

# 3. إصلاح ملف package.json الرئيسي وإزالة packageManager الخاص بـ pnpm
cat > package.json << 'EOF'
{
  "name": "bizai-factory",
  "version": "1.0.0",
  "private": true,
  "packageManager": "npm@11.7.0", 
  "workspaces": ["apps/*"],
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "lint": "turbo run lint",
    "clean": "rm -rf node_modules apps/*/node_modules .turbo"
  },
  "devDependencies": {
    "turbo": "^2.6.3"
  }
}
EOF

# 4. حذف التحذير القديم من .npmrc
if [ -f ".npmrc" ]; then
  # إزالة السطر الذي يسبب المشكلة فقط
  sed -i '/strict-peer-dependencies/d' .npmrc
  # إذا أصبح الملف فارغًا، احذفه
  [ -s ".npmrc" ] || rm -f .npmrc
fi

# 5. تحديث إصدار TypeScript في المشاريع الفرعية لتجنب مشكلة الإصدار
for app_dir in apps/*/; do
  if [ -f "${app_dir}package.json" ]; then
    echo "تحديث ${app_dir}package.json"
    sed -i 's/"typescript": "5\.3\.0"/"typescript": "^5.0.0"/' "${app_dir}package.json" 2>/dev/null || true
  fi
done

# 6. تنظيف وإعادة تثبيت
rm -rf node_modules apps/*/node_modules .turbo
npm install --legacy-peer-deps

echo "✅ تم التراجع. جرب الآن: npm run build"