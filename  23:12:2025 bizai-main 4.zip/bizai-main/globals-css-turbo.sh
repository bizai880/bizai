#!/bin/bash
cd /workspaces/bizai/apps/web

echo "🚀 تطبيق next.config.js مع turbopack..."

# 1. إنشاء next.config.js مع turbopack
cat > next.config.js << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: false,
  
  turbopack: {
    resolveExtensions: ['.tsx', '.ts', '.jsx', '.js', '.json', '.css'],
  },
  
  staticPageGenerationTimeout: 300,
}

module.exports = nextConfig
EOF

# 2. إصلاح package.json (حذف NODE_OPTIONS إذا كان يسبب مشاكل)
echo "📦 إصلاح package.json..."
cat > package.json << 'EOF'
{
  "name": "bizai-web",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "15.5.9",
    "react": "18.2.0",
    "react-dom": "18.2.0"
  },
  "devDependencies": {
    "@types/node": "^20.10.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "typescript": "^5.3.0"
  }
}
EOF

# 3. حل مشكلة globals.css بشكل نهائي
echo "🎨 إصلاح globals.css..."
cat > app/globals.css << 'EOF'
/* ملف CSS بسيط - بدون استيرادات */

:root {
  /* الخطوط - سيتم تحميلها في layout */
  --font-inter: 'Inter', sans-serif;
  --font-arabic: 'IBM Plex Sans Arabic', sans-serif;
  
  /* الألوان الأساسية */
  --primary: #0070f3;
  --background: #ffffff;
  --text-primary: #000000;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: var(--font-arabic);
  background: var(--background);
  color: var(--text-primary);
}
EOF

# 4. تحديث layout.tsx لتحميل الخطوط بشكل صحيح
echo "📝 تحديث layout.tsx..."
cat > app/layout.tsx << 'EOF'
import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'BizAI Factory - منصة أنظمة الأعمال الذكية',
  description: 'منصة متكاملة لتحويل الأوصاف النصية إلى أنظمة أعمال كاملة',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" 
          rel="stylesheet" 
        />
        <link 
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap&subset=arabic" 
          rel="stylesheet" 
        />
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
EOF

# 5. تنظيف وإعادة بناء
echo "🧹 تنظيف شامل..."
rm -rf .next
rm -rf node_modules/.cache

# 6. البناء مع turbopack
echo "🔨 البناء مع turbopack..."
npm run build 2>&1 | tee turbopack-build.log

if [ $? -eq 0 ]; then
    echo "✅ تم البناء بنجاح مع turbopack!"
else
    echo "❌ فشل البناء"
    echo "📋 الخطأ:"
    tail -30 turbopack-build.log
fi