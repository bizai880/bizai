#!/bin/bash
cd /workspaces/bizai

echo "🧹 بدء تنظيف Cache الشامل..."

# 1. تنظيف Turbo cache
echo "⚡ تنظيف Turbo cache..."
rm -rf .turbo 2>/dev/null || true
rm -rf node_modules/.cache/turbo 2>/dev/null || true
npx turbo daemon stop 2>/dev/null || true
npx turbo daemon clean 2>/dev/null || true

# 2. تنظيف Next.js cache في جميع المشاريع
echo "🔄 تنظيف Next.js cache..."
find . -name ".next" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name ".next-env.d.ts" -type f -delete 2>/dev/null || true

# 3. تنظيف npm cache
echo "📦 تنظيف npm cache..."
npm cache clean --force 2>/dev/null || true
rm -rf node_modules/.cache 2>/dev/null || true

# 4. تنظيف TypeScript cache
echo "📝 تنظيف TypeScript cache..."
find . -name "tsconfig.tsbuildinfo" -type f -delete 2>/dev/null || true
find . -name "*.tsbuildinfo" -type f -delete 2>/dev/null || true
find . -name ".tsbuild*" -type f -delete 2>/dev/null || true

# 5. تنظيف build artifacts
echo "🏗️  تنظيف ملفات البناء..."
find . -name "dist" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "build" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "out" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "*.log" -type f -delete 2>/dev/null || true

# 6. تنظيف OS-specific cache
echo "💻 تنظيف OS cache..."
find . -name ".DS_Store" -type f -delete 2>/dev/null || true
find . -name "Thumbs.db" -type f -delete 2>/dev/null || true
find . -name "*.swp" -type f -delete 2>/dev/null || true
find . -name "*.swo" -type f -delete 2>/dev/null || true

# 7. تنظيف IDE/Editor cache
echo "📝 تنظيف IDE cache..."
find . -name ".vscode" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name ".idea" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "*.iml" -type f -delete 2>/dev/null || true

# 8. تنظيف lock files إذا لزم
echo "🔒 تنظيف lock files..."
rm -f package-lock.json 2>/dev/null || true
rm -f yarn.lock 2>/dev/null || true
rm -f pnpm-lock.yaml 2>/dev/null || true

# 9. تنظيف node_modules في المشاريع الفرعية فقط (ليس الرئيسي)
echo "📁 تنظيف node_modules الفرعية..."
find apps -name "node_modules" -type d -exec rm -rf {} + 2>/dev/null || true
find packages -name "node_modules" -type d -exec rm -rf {} + 2>/dev/null || true

# 10. إضافة clean script إلى package.json الرئيسي
echo "📝 تحديث package.json الرئيسي..."
if [ -f "package.json" ]; then
    if ! grep -q '"clean"' package.json; then
        echo "➕ إضافة clean script..."
        
        if command -v jq &> /dev/null; then
            jq '.scripts.clean = "bash clean-cache.sh"' package.json > package.json.tmp && mv package.json.tmp package.json
        else
            sed -i '/"scripts": {/a\    "clean": "bash clean-cache.sh",' package.json
        fi
    fi
fi

# 11. حفظ هذا السكريبت كملف دائم
echo "💾 حفظ سكريبت التنظيف..."
cat > clean-cache.sh << 'EOF'
#!/bin/bash
# سكريبت تنظيف Cache الشامل
# تشغيل: bash clean-cache.sh أو npm run clean

echo "🧹 تنظيف Cache الشامل..."

# Turbo cache
echo "⚡ Turbo cache..."
rm -rf .turbo 2>/dev/null || true
rm -rf node_modules/.cache/turbo 2>/dev/null || true

# Next.js cache
echo "🔄 Next.js cache..."
find . -name ".next" -type d -exec rm -rf {} + 2>/dev/null || true

# npm cache
echo "📦 npm cache..."
rm -rf node_modules/.cache 2>/dev/null || true

# TypeScript cache
echo "📝 TypeScript cache..."
find . -name "tsconfig.tsbuildinfo" -type f -delete 2>/dev/null || true

# Build artifacts
echo "🏗️  Build artifacts..."
find . -name "dist" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "build" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name "out" -type d -exec rm -rf {} + 2>/dev/null || true

# Log files
echo "📄 Log files..."
find . -name "*.log" -type f -delete 2>/dev/null || true

echo "✅ تم التنظيف بنجاح!"
EOF

chmod +x clean-cache.sh

# 12. تحديث turbo.json لإضافة task clean
echo "⚡ تحديث turbo.json..."
if [ -f "turbo.json" ]; then
    if ! grep -q '"clean"' turbo.json; then
        cat > turbo.json << 'EOF'
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "dist/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "lint": {
      "outputs": []
    },
    "clean": {
      "cache": false
    }
  }
}
EOF
    fi
fi

# 13. إضافة clean script منفصل لكل package
echo "📦 إضافة clean scripts للمشاريع الفرعية..."

# للمشاريع الرئيسية
for dir in apps/web packages/shared packages/ai-core packages/database apps/ai-worker; do
    if [ -d "$dir" ]; then
        echo "📁 $dir"
        cd "$dir"
        
        if [ -f "package.json" ]; then
            if ! grep -q '"clean"' package.json; then
                if command -v jq &> /dev/null; then
                    jq '.scripts.clean = "rm -rf dist build .next .turbo"' package.json > package.json.tmp && mv package.json.tmp package.json
                else
                    sed -i '/"scripts": {/a\    "clean": "rm -rf dist build .next .turbo",' package.json
                fi
            fi
        fi
        
        cd /workspaces/bizai
    fi
done

# 14. إنشاء alias سريع
echo "🚀 إنشاء aliases سريعة..."
cat > ~/.bash_aliases 2>/dev/null << 'EOF'
# Clean aliases
alias clean-all='cd /workspaces/bizai && bash clean-cache.sh'
alias clean-turbo='rm -rf /workspaces/bizai/.turbo /workspaces/bizai/node_modules/.cache/turbo'
alias clean-next='find /workspaces/bizai -name ".next" -type d -exec rm -rf {} + 2>/dev/null'
alias clean-build='find /workspaces/bizai -name "dist" -o -name "build" -o -name "out" -type d -exec rm -rf {} + 2>/dev/null'
alias clean-cache='npm cache clean --force && rm -rf node_modules/.cache'
alias fresh-start='cd /workspaces/bizai && bash clean-cache.sh && npm install && npm run build'
EOF

# Load aliases if in current session
source ~/.bash_aliases 2>/dev/null || true

echo ""
echo "🎉 تم تنظيف Cache بنجاح!"
echo ""
echo "📋 الملفات التي تم تنظيفها:"
echo "   ✅ .turbo/"
echo "   ✅ .next/ (في جميع المجلدات)"
echo "   ✅ dist/ (في جميع المجلدات)"
echo "   ✅ build/ (في جميع المجلدات)"
echo "   ✅ node_modules/.cache/"
echo "   ✅ tsconfig.tsbuildinfo"
echo "   ✅ ملفات .log"
echo ""
echo "🚀 أوامر سريعة جديدة:"
echo "   npm run clean        # تنظيف Cache"
echo "   clean-all            # تنظيف شامل"
echo "   clean-turbo          # تنظيف Turbo فقط"
echo "   clean-next           # تنظيف Next.js فقط"
echo "   fresh-start          # تنظيف وإعادة تثبيت وبناء"
echo ""
echo "🔧 تم إنشاء ملف clean-cache.sh للاستخدام المستقبلي"